import urllib2,urllib,re,os
import xbmcplugin,xbmcgui,xbmc
import xbmcaddon,cookielib
from BeautifulSoup import BeautifulSoup as BS
USER_AGENT = "Mozilla/5.0 (X11; Linux x86_64; rv:10.0.1)"
" Gecko/20100101 Firefox/10.0.1"
# __settings__ = xbmcaddon.Addon(id="plugin.video.MyEntertainment")
# home = __settings__.getAddonInfo('path')

def SERIEN_FOLDER(url,br):
        import entertain
        br=br
        content = br.open(url)
        data = content.read()
        data=data.replace('\xf6',"oe").replace('&amp;',"&").replace('\xd6',"Oe").replace('\xdc',"Ue").replace('\xfc',"ue").replace('\xc4',"Ae").replace('\xe4',"ae").replace('\xdd',"I").replace('\xfd',"i").replace('\xe7',"c").replace('\xde',"s").replace('\xfe',"s").replace('\xc7',"c").replace('\xf0',"g").replace('\xdf',"ss").replace('\xe9',"e")
        match=re.compile('<a href="(.*?)"><span>(.*?)</span></a>').findall(data)
        match2=re.compile('title="(.*?)">\r\n\t\t(.*?)\r').findall(data)
        value=[]
        link=data
        soup = BS(link)
        for div in soup.findAll('div',  {"class": "article_preview"},smartQuotesTo=None):
            name= div.find('span').find(text=True)
            url= div.find('a')['href']
            resim=div.find('img')['src']
            value.append((name,resim,url))
        for name, resim, url in value:
            entertain.enter_addDir(name,url,'',13,resim,'')
        
        for name, zahl in match2:
            entertain.enter_addDir('Serien '+str(name),'http://my-entertainment.biz/forum/content.php?r=1072-Serien&page='+str(zahl),'',12,'','')
        xbmc.executebuiltin("Container.SetViewMode(500)")

def LINKS(url,br):
        content = br.open(url)
        data = content.read()
        try:
            status = re.search('Status:</span> &nbsp; <span style="color: #FF6600;">(.*?)</span>', data).group(1)
            if status == 'Premium Member':
                data=data.replace('\xf6',"oe").replace('&amp;',"&").replace('\xd6',"Oe").replace('\xdc',"Ue").replace('\xfc',"ue").replace('\xc4',"Ae").replace('\xe4',"ae").replace('\xdd',"I").replace('\xfd',"i").replace('\xe7',"c").replace('\xde',"s").replace('\xfe',"s").replace('\xc7',"c").replace('\xf0',"g").replace('\xdf',"ss").replace('\xe9',"e")
                match=re.compile('<a href="(.*?)" target=.*?>(.*?)</a><').findall(data)
        ##for url1, name in match:
        #print str(match)
                import entertain
                for url1,name in match:
                    entertain.enter_addDir(name,url1,'',14,'','')
        except:
                pass
        # for i in match:
            # if 's01' in i[0]:
                # print ("this is it:",i[0])
                # default.addDir('Staffel 1',url,6,'')

        # if "s02" or "S02" in str(match):
            # default.addDir('Staffel 2',url,6,'')

        # if "s03" or "S03" in str(match):
            # default.addDir('Staffel 3',url,6,'')

        # if "s04" or "S04" in str(match):
            # default.addDir('Staffel 4',url,6,'')

        # if "s05" or "S05" in str(match):
            # default.addDir('Staffel 5',url,6,'')

        # if "s06"or"S06" in str(match):
            # default.addDir('Staffel 6',url,6,'')

        # if "s07" or "S07" in str(match):
            # default.addDir('Staffel 14',url,6,'')

        # if "s08" or "S08" in str(match):
            # default.addDir('Staffel 8',url,6,'')

        # if "s09"or"S09" in str(match):
            # default.addDir('Staffel 9',url,6,'')

        # if "s10" or "S10" in str(match):
            # default.addDir('Staffel 10',url,6,'')

        # if "s11" or "S11" in str(match):
            # default.addDir('Staffel 11',url,6,'')

        # if "s12" or "S12" in str(match):
            # default.addDir('Staffel 12',url,6,'')

        # if "S01" or "s01" not in match:
            # for url1,name in match:
                # default.addDir(name,url1,14,'')

def PLAYLINK(url):##THX to xmaxell from XBMXTR
        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('<meta http-equiv="refresh" content="0;url=(.*?)" />\n').findall(link)
        for a in match:
            url=a
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        cookie = response.info().getheader('Set-Cookie')  
        response.close()
        match=re.compile('<input type="hidden" name="op" value="(.*?)">\n\t\t\t\t\t\t<input type="hidden" name="usr_login" value="(.*?)">\n\t\t\t\t\t\t<input type="hidden" name="id" value="(.*?)">\n\t\t\t\t\t\t<input type="hidden" name="fname" value="(.*?)">\n\t\t\t\t\t\t<input type="hidden" name="referer" value="(.*?)">\n\t\t\t\t\t\t<input type="hidden" name="hash" value="(.*?)">\n\t\t\t\t\t\t<input type="submit" name="imhuman" .*? value="(.*?)">').findall(link)

        for op,usr_login,id,fname,referer,hash,imhuman in match:
            import time
            time.sleep(11)

            gidecekveriler=urllib.urlencode({'op' : op, 'usr_login' : usr_login, 'id' : id, 'fname' : fname, 'referer' : referer, 'hash' : hash, 'imhuman' : imhuman.replace(" ","+")})
            req=urllib2.Request(url)
            req.add_header('Referer', url)
            req.add_data(gidecekveriler)
            req.add_header('Cookie',cookie)
            post = urllib2.urlopen(req)
            gelen_veri=post.read()
            gelen_veri=re.compile('file: "(.+?)"').findall(gelen_veri) 
            for final in gelen_veri:
                    url=final
                    import entertain
                    entertain.enter_addLink('play',url,'','','')
                    playList.add(url)
