# -*- coding: utf-8 -*-
import sys
import mechanize
import urllib2,urllib,re,os
import xbmcplugin,xbmcgui
import xbmcaddon,xbmc
from BeautifulSoup import BeautifulSoup as BS
def br():
        USER_AGENT = "Mozilla/5.0 (X11; Linux x86_64; rv:10.0.1)"
        " Gecko/20100101 Firefox/10.0.1"
        __settings__ = xbmcaddon.Addon(id="plugin.video.MyEntertainment")
        login= __settings__.getSetting("login")
        password= __settings__.getSetting("password")
        url_start='http://my-entertainment.biz/forum/forum.php'
        if not login:
                __settings__.openSettings()
        else:
                pass
        br = mechanize.Browser()
        br.open(url_start)
        br.select_form(nr=0)
        br["vb_login_username"] = str(login)
        br["vb_login_password"] = str(password)
        response1 = br.submit()
        fc = response1.read()
        if "Danke" in str(fc):
            print "Succesfully Loged in."
        else:
            __settings__.openSettings()
        return br

def INDEX_GENRE(url,br):
        enter_addDir(' Suche...','http://my-entertainment.biz/forum/content.php?r=1969-Aktuelle-HD-Filme&page=','',17,'','')
        enter_addDir(' Neueinsteiger',url,'',8,'','')
        enter_addDir(' Aktuelle HD Filme','http://my-entertainment.biz/forum/content.php?r=3938-Aktuelle','',8,'','')
        enter_addDir(' Collections','http://my-entertainment.biz/forum/content.php?r=3501-hd-collection&page=1','',8,'','')
        enter_addDir(' Serien','http://my-entertainment.biz/forum/content.php?r=1072-Serien','',12,'','')
        enter_addDir(' 3d Filme','http://my-entertainment.biz/forum/content.php?r=4225-3d-filme','',8,'','')
        #Search(url)
        content = br.open(url)
        data = content.read()
        data=data.replace('\xf6',"oe").replace('&amp;',"&").replace('\xd6',"Oe").replace('\xdc',"Ue").replace('\xfc',"ue").replace('\xc4',"Ae").replace('\xe4',"ae").replace('\xdd',"I").replace('\xfd',"i").replace('\xe7',"c").replace('\xde',"s").replace('\xfe',"s").replace('\xc7',"c").replace('\xf0',"g").replace('\xdf',"ss").replace('\xe9',"e")
        match=re.compile('<div class="cat_main_menuitem">\n<a href="(.*?)">HD:(.*?)</a>\n</div>').findall(data)
        for url,name in match:
            enter_addDir(name,url,'',8,'','')
        xbmc.executebuiltin("Container.SetViewMode(300)")
        
def INDEX(url,name,br):
        content = br.open(url)
        data = content.read()
        data=data.replace('\xf6',"oe").replace('&amp;',"&").replace('\xd6',"Oe").replace('\xdc',"Ue").replace('\xfc',"ue").replace('\xc4',"Ae").replace('\xe4',"ae").replace('\xdd',"I").replace('\xfd',"i").replace('\xe7',"c").replace('\xde',"s").replace('\xfe',"s").replace('\xc7',"c").replace('\xf0',"g").replace('\xdf',"ss").replace('\xe9',"e").replace('\xb7',"-")
        if 'Collections' in name:
            value=[]
            link=data
            soup = BS(link)
            for div in soup.findAll('div',  {"class": "article_preview"},smartQuotesTo=None):
                attr= div.findAll('a')
                attribute=[]
                for i in attr:
                    attribute.append(i.string) 
                name= div.find('span').find(text=True)
                url= div.find('a')['href']
                resim=div.find('img')['src']
                try:
                    value.append((name,resim,url,(attribute[2].replace("IMDB ",""))))
                except:
                    value.append((name,resim,url,''))
            for name, resim, url, imdb in value:
                enter_addDir(str(name+'[CR][I]imdb-'+str(imdb)+'[/I]'),url,'',11,resim,imdb)
            match=re.compile('title="(.*?)">\r\n\t\t(.*?)\r').findall(data)
            for name, zahl in match:
                enter_addDir('Collections '+str(name),'http://my-entertainment.biz/forum/content.php?r=3501-hd-collection&page='+str(zahl),'',8,'','')

        else:
            value=[]
            link=data
            soup = BS(link)
            for div in soup.findAll('div',  {"class": "article_preview"},smartQuotesTo=None):
                attr= div.findAll('a')
                attribute=[]
                for i in attr:
                    attribute.append(i.string) 
                name= div.find('span').find(text=True)
                url= div.find('a')['href']
                resim=div.find('img')['src']
                try:
                    value.append((name,resim,url,(attribute[2].replace("IMDB ",""))))
                except:
                    value.append((name,resim,url,''))
            for name, resim, url, imdb in value:
                if "Saga" in name:
                    enter_addDir(str(name+'[CR][I]imdb-'+str(imdb)+'[/I]'),url,'',11,resim,imdb)
                elif "Trilogie" in name:
                    enter_addDir(str(name+'[CR][I]imdb-'+str(imdb)+'[/I]'),url,'',11,resim,imdb)
                elif "Collection" in name:
                    enter_addDir(str(name+'[CR][I]imdb-'+str(imdb)+'[/I]'),url,'',11,resim,imdb)
                elif "Trilogy" in name:
                    enter_addDir(str(name+'[CR][I]imdb-'+str(imdb)+'[/I]'),url,'',11,resim,imdb)
                elif "Quadrologie" in name:
                    enter_addDir(str(name+'[CR][I]imdb-'+str(imdb)+'[/I]'),url,'',11,resim,imdb)
                elif "Quadrilogy" in name:
                    enter_addDir(str(name+'[CR][I]imdb-'+str(imdb)+'[/I]'),url,'',11,resim,imdb)
                elif "Anthologie" in name:
                    enter_addDir(str(name+'[CR][I]imdb-'+str(imdb)+'[/I]'),url,'',11,resim,imdb)
                elif 'HD:' in name:
                    enter_addDir(str(name+'[CR][I]imdb-'+str(imdb)+'[/I]'),url,'',9,resim,imdb)
                elif '3D' in name:
                    enter_addDir(str(name+'[CR][I]imdb-'+str(imdb)+'[/I]'),url,'',9,resim,imdb)
                else:
                    enter_addDir(str(name+'[CR][I]Serie[/I]'),url,'',13,resim,'')
            match=re.compile('<span><a href="(.*?)" title="(.*?)">').findall(link)
            for url,name in match:
                enter_addDir(name,url,'',8,'','')
        xbmc.executebuiltin("Container.SetViewMode(500)")

def SEARCH(url1,br):
        kb = xbmc.Keyboard('', 'Search My-Entertainment.biz', False)
        kb.doModal()
        search = kb.getText()
        search = search.replace(' ',"+")
        content = br.open('http://my-entertainment.biz/forum/search.php?query='+search+'&titleonly=0&searchdate=0&beforeafter=after&contenttypeid=18&type[]=18&sortby=relevance&order=descending&sortorder=desc&saveprefs=1&type[]=18&do=process')
        data = content.read()
        data=data.replace('\xf6',"oe").replace('&amp;',"&").replace('\xd6',"Oe").replace('\xdc',"Ue").replace('\xfc',"ue").replace('\xc4',"Ae").replace('\xe4',"ae").replace('\xdd',"I").replace('\xfd',"i").replace('\xe7',"c").replace('\xde',"s").replace('\xfe',"s").replace('\xc7',"c").replace('\xf0',"g").replace('\xdf',"ss").replace('\xe9',"e").replace('\xb7',"-")
        value=[]
        link=data
        soup = BS(link)
        for div in soup.findAll('h3',  {"class": "searchtitle"},smartQuotesTo=None):
            name= div.find('a').find(text=True)
            url= div.find('a')['href']
            try:
                value.append((name,url))
            except:
                value.append((name,url))
        for name, url in value:
            if "Saga" in name:
                enter_addDir(name,url,'',11,'','')
            elif "Trilogie" in name:
                enter_addDir(name,url,'',11,'','')
            elif "Collection" in name:
                enter_addDir(name,url,'',11,'','')
            elif "Trilogy" in name:
                enter_addDir(name,url,'',11,'','')
            elif "Quadrologie" in name:
                enter_addDir(name,url,'',11,'','')
            elif "Quadrilogy" in name:
                enter_addDir(name,url,'',11,'','')
            elif "Anthologie" in name:
                enter_addDir(name,url,'',11,'','')
            elif 'HD:' in name:
                enter_addDir(name,url,'',9,'','')
            elif '3D' in name:
                enter_addDir(name,url,'',9,'','')
            else:
                enter_addDir(name,url,'',13,'','')
        match=re.compile('<span><a href="(.*?)" title="(.*?)">').findall(link)
        for url,name in match:
            enter_addDir(name,url,'',8,'','')
        xbmc.executebuiltin("Container.SetViewMode(400)")
        
def VIDEOLINKS(url,name,thumbnail,imdb,br):
        content = br.open(url)
        data = content.read()
        try:
            status = re.search('Status:</span> &nbsp; <span style="color: #FF6600;">(.*?)</span>', data).group(1)
            if status == 'Premium Member':
                data = data=data.replace('\xb2',"2").replace('\xb3',"3").replace('\xf6',"oe").replace('&amp;',"&").replace('\xd6',"Oe").replace('\xdc',"Ue").replace('\xfc',"ue").replace('\xc4',"Ae").replace('\xe4',"ae").replace('\xdd',"I").replace('\xfd',"i").replace('\xe7',"c").replace('\xde',"s").replace('\xfe',"s").replace('\xc7',"c").replace('\xf0',"g").replace('\xdf',"ss").replace('\xe9',"e").replace('<font size="4">',"").replace('</font>',"").replace('br /',"").replace('<b>',"").replace('%3D',"=").replace('%26',"&").replace('%3F',"?").replace('%2F',"/").replace('%3A',":").replace('\xe4',"ae")
                match=re.compile('<a href="(.*?)" target="Videoframe').findall(data)
                plot=''
                thumbnail = ''
                link_name = ''
                link_name1=''
                tmp_url = ''
                soup = BS(data)
                for div in soup.findAll('div',  {"class": "quote_container"}):
                    plot = str(div(text=True)[1])
                for div in soup.findAll('div', {"class": "article cms_clear restore postcontainer"}):
                    thumbnail = div.find('img')['src'] 
                for i in match:
                    if 'Premium-Member' in i:
                        tmp_url = tmp_url + str(i)
                        link_name = (name+' [I](HD Plus)[/I]')
                    elif 'Non-Premium-Member' in i:
                        link_name = 'Kein Premium Mitglied'
                dir_vid = br.open(tmp_url)
                video = dir_vid.read()
                video_match = re.compile('src="(.*?)"').findall(video)
                if link_name !='':
                    try:
                        enter_addLink(link_name,video_match[0],thumbnail,'',plot)
                    except:
                        enter_addLink(link_name,video_match[0],'','','')
                else:
                        pass
                tmp_url1=''
                if link_name !='':
                    for i in match:
                        if 'Free-Member' in i:
                            tmp_url1 = tmp_url1 + str(i)
                            link_name1 = (name+' [I](HD Free)[/I]')
                    if link_name1 !='':
                        try:
                            enter_addDir(link_name1,tmp_url1,url,15,thumbnail,'')            
                        except:
                            enter_addDir(link_name1,tmp_url1,url,15,'','') 
                        else:
                                pass
        except:
                pass
        xbmc.executebuiltin("Container.SetViewMode(400)")

def play_free_video(url,name,thumbnail,imdb,br):
        pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        pl.clear()
        try:
            dir_vid = br.open(url)
            video1 = dir_vid.read()
            video_match1 = re.compile('src="(.*?)" type="video/mp4"').findall(video1)
            link = video_match1[0]
            print video_match1[0]
            enter_addLink(name,link,thumbnail,imdb,'')
            listitem = xbmcgui.ListItem(name,thumbnailImage=thumbnail)
            xbmc.PlayList(1).add(link, listitem)
            xbmc.Player().play(pl) 
        except:
                pass

def LINKS_COLLECTIONS(url,br):
        content = br.open(url)
        data = content.read()
        data=data.replace('\xb2',"2").replace('\xb3',"3").replace('\xf6',"oe").replace('&amp;',"&").replace('\xd6',"Oe").replace('\xdc',"Ue").replace('\xfc',"ue").replace('\xc4',"Ae").replace('\xe4',"ae").replace('\xdd',"I").replace('\xfd',"i").replace('\xe7',"c").replace('\xde',"s").replace('\xfe',"s").replace('\xc7',"c").replace('\xf0',"g").replace('\xdf',"ss").replace('\xe9',"e").replace('<font size="4">',"").replace('/font',"").replace('br /',"").replace('<b>',"").replace('%3D',"=").replace('%26',"&").replace('%3F',"?").replace('%2F',"/").replace('%3A',":").replace('\xe4',"ae").replace('<font size="3">',"")
        match=re.compile('<a href="(.*?)" target=".*?">').findall(data)
        match_name=re.compile('>*\s*\r*\n<.*?>*\r*\n*\s(.*?)<.*?>*\r*\n*\s*<*>*\r*\n*<div style="margin:').findall(data)
        for i in match_name:
            print i
        match_video_HDPlus=[]
        match_video_Free=[]
        free = 0
        plus = 0
        try:
            status = re.search('Status:</span> &nbsp; <span style="color: #FF6600;">(.*?)</span>', data).group(1)
            if status == 'Premium Member':
                for index, i in enumerate(match):
                    print ("Free: ",free)
                    print ("Plus: ",plus)
                    tmp_url = ''
                    if 'Premium-Member' in i:
                        if plus==free:
                            plus=plus+1
                        elif plus<free+1:
                            plus=plus+1
                        elif plus==free+1:
                            free=free+1
                            plus=plus+1
                        elif plus==free+2:
                            free=free+3
                            plus=plus+1
                        tmp_url = tmp_url + str(i)
                        dir_vid = br.open(tmp_url)
                        video = dir_vid.read()
                        video_match = re.compile('src="(.*?)"').findall(video)
                        try:
                            enter_addLink(match_name[plus-1]+'[CR] [I](HD Plus)[/I]',video_match[0],'','','')
                        except:
                                pass
                    elif 'Free-Member' in i:
                        if free==plus:
                            free=free+1
                        elif free<plus+1:
                            free=free+1
                        elif free==plus+1:
                            plus=plus+1
                            free=free+1
                        elif free==plus+2:
                            plus=plus+3
                            free=free+1
                        tmp_url = tmp_url + str(i)
                        match_video_Free.append(tmp_url)
                        try:
                            enter_addDir(match_name[free-1]+'[CR] [I](HD Free)[/I]',tmp_url,url,15,'','')
                        except:
                            enter_addLink('Ueberlastet'+match_name[free],i,'','','')
        except:
                pass
        xbmc.executebuiltin("Container.SetViewMode(400)")

def get_attr(url,br):
        content = br.open(url)
        data = content.read()
        link=data.replace('\xf6',"oe").replace('&amp;',"&").replace('\xd6',"Oe").replace('\xdc',"Ue").replace('\xfc',"ue").replace('\xc4',"Ae").replace('\xe4',"ae").replace('\xdd',"I").replace('\xfd',"i").replace('\xe7',"c").replace('\xde',"s").replace('\xfe',"s").replace('\xc7',"c").replace('\xf0',"g").replace('\xdf',"ss").replace('\xe9',"e")
        value=[]
        soup = BS(link)
        for ol in soup.findAll('ol',  {"class": "commalist"},smartQuotesTo=None):
            attr= ol.findAll('a')
            attribute=[]
            for i in attr:
                attribute.append(i.string)
            value.append(attribute)
        return value
        
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
        
def enter_addLink(name,url,iconimage,imdb,plot):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Rating": imdb, "Plot": plot, "MPAA": imdb } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok

def enter_addDir(name,url,url0,mode,iconimage,imdb):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&url0="+urllib.quote_plus(url0)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&imdb="+urllib.quote_plus(imdb)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name,"Rating": imdb } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

