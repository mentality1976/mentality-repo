# Beceriksizler HD MOVIES plugin written by Mentality
# -*- coding: utf-8 -*-

import re
import os
import urllib,urllib2,urlresolver
import xbmcplugin,xbmcgui
import xbmcaddon
import webbrowser
from BeautifulSoup import BeautifulSoup as BS
import mechanize,gzip,shutil
from thread import start_new_thread

addon_id = 'plugin.video.beceriksizler'
addon = xbmcaddon.Addon(addon_id)
__settings__ = xbmcaddon.Addon(id="plugin.video.beceriksizler")
status = __settings__.getSetting("status")
datapath = __settings__.getAddonInfo('path')
channels = xbmc.translatePath(os.path.join(datapath, 'resources', 'lib'))
sys.path.append(channels)
channels = xbmc.translatePath(os.path.join(datapath, 'database'))
sys.path.append(channels)
import Stream_Update as su
import jsunpack
from net import Net
net = Net()
files = os.listdir(channels)
global imps
imps = []
for i in range(len(files)):
    if 'xml.gz' in files[i]:
        py_name = files[i].split('.')
        py_name = py_name[0]
        imps.append(py_name.decode(sys.getfilesystemencoding()).encode('utf-8'))

USER_AGENT = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'

def CATEGORIES():
        addDir('Beceriksizler HD MOVIES','https://dl.dropboxusercontent.com/u/18809002/Playlist/Home.xml',1,'http://beceriksizler.beep.to/images/Beceriksizler.png','')
        addDir('Stream-Oase HD MOVIES','http://stream-oase.tv/index.php/hd-oase',2,'http://www.abload.de/img/unbenannt2w4uwf.png','')
        xbmc.executebuiltin("Container.SetViewMode(500)")

def INDEX_NAVI(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        link=link.replace('\xf6',"o").replace('&amp;',"&").replace('\xd6',"O").replace('\xfc',"u").replace('\xdd',"I").replace('\xfd',"i").replace('\xe7',"c").replace('\xde',"s").replace('\xfe',"s").replace('\xc7',"c").replace('\xf0',"g").replace(u'\ufeff',"")
        response.close()
        match=re.compile('type=(.*?)\nname=(.*?)\nthumb=(.*?)\nURL=(.*?)\n').findall(link)
        for type,name,thumbnail,url in match:
            if type=='playlist':
                try:
                    addDir(name,url,5,thumbnail,'')
                    if match[-1]:
                        xbmc.executebuiltin("Container.SetViewMode(500)")
                except:
                        pass
            elif type=='video':
                try:
                    addDir(name,url,3,thumbnail,'')
                    if match[-1]:
                        xbmc.executebuiltin("Container.SetViewMode(500)")    
                except:
                        pass
            
                        
def index_test(url1):
        req = urllib2.Request(url1)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()      
        response.close()
        soup = BS(link)
        for movie in soup.findAll('movie'):
            type = str(movie.find('type').find(text=True))
            name = str(movie.find('name').find(text=True))
            thumb = str(movie.find('thumb').find(text=True))
            fanart = ''
            try:
                fanart = str(movie.find('fanart').find(text=True))
            except:
                    pass
            url = ''
            link = str(url)
            try:
                url=(url+str(movie.find('url')))
            except:
                pass
            try:
                url=url+str(movie.find('url1'))
            except:
                pass
            try:
                url=url+str(movie.find('url2'))
            except:
                pass
            if type=='playlist':
                try:
                    addDir(name,str(movie.find('url').find(text=True)),5,thumb,'')
                except:
                        print 'eins'
            elif type=='video':
                try:
                    addDir(name,url,3,thumb,fanart)   
                except:
                        print 'zwei'
        xbmc.executebuiltin("Container.SetViewMode(500)")    

def INDEX_OASE(url):
        try:
            req = urllib2.Request(url)
            req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
            response = urllib2.urlopen(req)
            link=response.read()
            response.close()
            soup = BS(link)
            value=[]
            for div in soup.find('div',  {"class": "mod-wrapper-menu clearfix"},smartQuotesTo=None).findAll('div',  {"class": "avs_thumb"},smartQuotesTo=None):
                url= div.find('a')['href']
                img= div.find('img').findNext('img')['src']
                name= div.find('span').find(text=True)
                name=name.encode('utf8')
                value.append((url, img, name))
            addDir('OASE Suche...','http://stream-oase.tv/',16,'http://stream-oase.tv/images/HDKategorie/HD%20Oasen%20Kategorie%20Transparenz.png','')
            addDir('New Videos','/index.php/hd-oase/video/latest',6,'http://stream-oase.tv/images/HDKategorie/HD%20Oasen%20Kategorie%20Transparenz.png','')
            for url,thumbnail,name in value:
                try:
                        addDir(name,url,6,thumbnail,'')
                        if match[-1]:
                            xbmc.executebuiltin("Container.SetViewMode(57)")
                except:
                        pass
        except:
            for i in imps:
                addDir(i,'yok bisi',6,str(channels)+'/Transparenz.png','')

def VIDEOLINKS_NAVI(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        link=link.replace('\xc3\xa4',"ae").replace('&amp;',"&").replace('\xd6',"O").replace('\xfc',"u").replace('\xdd',"I").replace('\xfd',"i").replace('\xe7',"c").replace('\xde',"s").replace('\xc3\x9f',"ss").replace('\xc2\xb4',"-").replace('\xc3\xb6',"oe").replace('\xc3\xbc',"ue")
        response.close()
        match=re.compile('type=(.*?)\nname=(.*?)\nthumb=(.*?)\nURL=(.*?)\n').findall(link)
        
        for type,name1,thumbnail,url in match:
            if type=='playlist':
                try:
                    addDir(name1,url,5,thumbnail,'')
                    if match[-1]:
                        xbmc.executebuiltin("Container.SetViewMode(500)")
                except:
                        print 'vier'
            elif type=='video':
                try:
                    addDir(name1,url,3,thumbnail,'')
                    if match[-1]:
                        xbmc.executebuiltin("Container.SetViewMode(500)")
                except:
                        print 'funf'

def VIDEOLINKS_OASE(name,url):
        if url!='yok bisi':
            nuna='http://stream-oase.tv'+url
        else:
                pass
        name1 = name.decode('utf-8').encode(sys.getfilesystemencoding())
        try:
            video_db = gzip.open(  os.path.join(channels, name1+'.xml.gz'),"r")
            video_db_str = video_db.read().decode('utf-8').encode('utf-8')
            video_db.close()
            shutil.copyfile(  os.path.join(channels, name1+'.xml.gz'),os.path.join(channels, name1+'.xml.bak'))
        except:
            shutil.copyfile(  os.path.join(channels, name1+'.xml.bak'),os.path.join(channels, name1+'.xml.gz'))
            video_db = gzip.open(  os.path.join(channels, name1+'.xml.gz'),"r")
            video_db_str = video_db.read().decode('utf-8').encode('utf-8')
            video_db.close()
        try:
            start_new_thread(su.hazirla,(name1,nuna))
        except:
                print 'sayfa yuklenemiyor'
        soup=BS(video_db_str)
        value = []
        for item in soup.findAll('item',smartQuotesTo=None):
            fanart= item.find('fanart').text
            img= item.find('thumbnail').text
            name= (item.find('title').text).encode('utf-8')
            try:
                url1 = item.find('link1').text
            except:
                url1 = ''
            try:
                url2 = item.find('link2').text
            except:
                url2 = ''
            value.append((';'.join([url1,url2]),fanart, img, name))
        if name1=='New Videos':
            for url1,fanart,thumbnail,name in reversed(value):
                try:
                        addDir(name,url1,4,thumbnail,fanart)
                except:
                        pass
        else:
            for url1,fanart,thumbnail,name in reversed(value):
                try:
                        addDir(name,url1,4,thumbnail,fanart)
                except:
                        pass
        xbmc.executebuiltin("Container.SetViewMode(500)")

def SEARCH_OASE(url):
        kb = xbmc.Keyboard('', 'Search Stream-oase.tv', False)
        kb.doModal()
        search = kb.getText()
        br = mechanize.Browser()
        br.open(url)
        br.select_form("hsearch")
        br["avssearch"] = search
        response = br.submit()
        link = response.read()
        response.close()
        soup = BS(link)
        value=[]
        for div in soup.find('div',  {"class": "sp-component-area-inner clearfix"},smartQuotesTo=None).findAll('div',  {"class": "avs_thumb"},smartQuotesTo=None):
            url= div.find('a')['href']
            print url
            img= div.find('img').findNext('img')['src']
            name= div.find('span').find(text=True)
            name=name.encode('utf8')
            value.append((url, img, name))
        for url1,thumbnail,name in value:
            try:
                    addDir(name,url1,4,thumbnail,'')
            except:
                    pass
        xbmc.executebuiltin("Container.SetViewMode(500)")

def get_fanart(name):
        url='http://www.themoviedb.org'
        br = mechanize.Browser()
        br.open(url)
        br.select_form(nr=0)
        br["query"] = name
        response = br.submit()
        link = response.read()
        response.close()
        soup = BS(link)
        video = soup.find('ul', {"class": "search_results movie"}).find('a')['href']
        req = urllib2.urlopen(url+video)
        link = req.read()
        soup2 = BS(link)
        img = (soup2.find('div', {"id": "images"}).find('img')['src']).replace("w300","original")
        return img
        
def PLAYLINK_NAVI(url,name,iconimage,fanart):
        try:
            link=re.search('<url>(.*?)</url>', url).group(1)
            try:
                addDir(name+hoster(link),str(link),10,iconimage,fanart)
            except:
                   addDir(name+hoster(link),str(link),10,iconimage,'') 
        except:
                print 'sechs'
        try:
            link1=re.search('<url1>(.*?)</url1>', url).group(1)
            try:
                addDir(name+hoster(link1),str(link),10,iconimage,fanart)
            except:
                   addDir(name+hoster(link1),str(link),10,iconimage,'') 
        except:
                print 'sieben'
        try:
            link2=re.search('<url2>(.*?)</url2>', url).group(1)
            try:
                addDir(name+hoster(link2),str(link),10,iconimage,fanart)
            except:
                   addDir(name+hoster(link2),str(link),10,iconimage,'') 
        except:
                print 'acht'

def hoster(link):
        if 'vidhog'in link:
            host='[CR][I]Vidhog[/I]'
        elif 'mightyupload' in link:
            host='[CR][I]Mightyupload[/I]'
        elif '180upload' in link:
            host='[CR][I]180upload[/I]'
        elif 'hugefiles' in link:
            host='[CR][I]Hugefiles[/I]'
        return host

def PLAYLINK_OASE(url,name,iconimage,fanart):
        url1 = url.split(';')
        print str(url1)
        for link in url1:
            # try:
                print 'BENIM : '+link
                ref = re.search('http://(.*?)/.*?',link).group(1)
                ref = ref.replace("www.", '').replace(".com",'').replace(".net",'')
                print ref
                try:
                    addDir(name+'[CR][I]'+ref+'[/I]',str(link),10,iconimage,fanart)
                except:
                    addDir(name+'[CR][I]'+ref+'[/I]',str(link),10,iconimage,'')
           
def resolve_hugefiles(name,url,iconimage,fanart):
        ok=True
        playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playlist.clear()
        listitem = xbmcgui.ListItem(name, iconImage=iconimage)
        listitem.setInfo('video', {'Title': name, 'Year': ''} )
        hosted_media = urlresolver.HostedMediaFile(url)
        source = hosted_media
        stream_url=[]
        if source:
                xbmc.executebuiltin("XBMC.Notification(Please Wait!,Resolving Link,3000)")
                stream_url = source.resolve()
                print str(stream_url)
        else:
              stream_url = False
        addLink(name,stream_url,iconimage,str(fanart))
        playlist.add(str(stream_url),listitem)
        xbmcPlayer = xbmc.Player()
        xbmcPlayer.play(playlist)
        return ok
        
def resolve_mightyupload(name,url,iconimage,fanart):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        html=response.read()
        pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        pl.clear()
        try:
            sPattern = '''<div id="player_code">.*?<script type='text/javascript'>(eval.*?)</script>'''
            r = re.search(sPattern, html, re.DOTALL + re.IGNORECASE)
            #print str(r.group(1))

            if r:
                sJavascript = r.group(1)
                sUnpacked = jsunpack.unpack(sJavascript)
                sPattern = "'file','([^']*)'";
                r = re.search(sPattern, sUnpacked).group(1)
                addLink(name,r,iconimage,str(fanart))
                listitem = xbmcgui.ListItem(name,thumbnailImage=iconimage)
                url = r
                xbmc.PlayList(1).add(url, listitem)
                xbmc.Player().play(pl)
        except Exception, e:
            dialog = xbmcgui.DialogProgress()
            dialog1 = xbmcgui.Dialog()
            dialog1.ok('error','[UPPERCASE][B]                Sorry but the video is deleted!!![/B][/UPPERCASE]')
            print '**** mightyupload Error occured: %s' % e
            raise
            
def resolve_180upload(name1,url,iconimage,fanart):
        pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        pl.clear()
        try:
            dialog = xbmcgui.DialogProgress()
            if '180upload' in url:
                dialog.create('Resolving', 'Resolving 180Upload Link...')
            else:
                dialog.create('Resolving', 'Resolving vidplay Link...')
            dialog.update(0)
            puzzle_img = os.path.join(datapath, "180_puzzle.png")
            
            print '180Upload - Requesting GET URL: %s' % url
            html = net.http_GET(url).content

            dialog.update(50)
                    
            data = {}
            r = re.findall(r'type="hidden" name="(.+?)" value="(.+?)">', html)

            if r:
                for name, value in r:
                    data[name] = value
            else:
                dialog1 = xbmcgui.Dialog()
                dialog1.ok('error','[UPPERCASE][B]                Sorry but the video is deleted!!![/B][/UPPERCASE]')
            
            #Check for SolveMedia Captcha image
            solvemedia = re.search('<iframe src="(http://api.solvemedia.com.+?)"', html)

            if solvemedia:
                dialog.close()
                html = net.http_GET(solvemedia.group(1)).content
                hugekey=re.search('id="adcopy_challenge" value="(.+?)">', html).group(1)
                open(puzzle_img, 'wb').write(net.http_GET("http://api.solvemedia.com%s" % re.search('<img src="(.+?)"', html).group(1)).content)
                img = xbmcgui.ControlImage(450,15,400,130, puzzle_img)
                wdlg = xbmcgui.WindowDialog()
                wdlg.addControl(img)
                wdlg.show()
            
                xbmc.sleep(3000)

                kb = xbmc.Keyboard('', 'Type the letters in the image', False)
                kb.doModal()
                capcode = kb.getText()
       
                if (kb.isConfirmed()):
                    userInput = kb.getText()
                    if userInput != '':
                        solution = kb.getText()
                    elif userInput == '':
                        Notify('big', 'No text entered', 'You must enter text in the image to access video', '')
                        return False
                else:
                    return False
                   
                wdlg.close()
                if '180upload' in url:
                    dialog.create('Resolving', 'Resolving 180Upload Link...')
                else:
                    dialog.create('Resolving', 'Resolving vidplay Link...')
                dialog.update(50)
                if solution:
                    data.update({'adcopy_challenge': hugekey,'adcopy_response': solution})

            print '180Upload - Requesting POST URL: %s' % url
            html = net.http_POST(url, data).content
            dialog.update(100)
            if '180upload'in url:
                link = re.search('<a href="(.+?)" onclick="thanks\(\)">Download now!</a>', html)
            else:
                link = re.search('href="(.*?)" title="Direct download the file"', html)
            link = link.group(1)
            link = link.replace(" ", "_")
            if link:
                print '180Upload Link Found: %s' % link.encode('utf8')
                addLink(name1,link,iconimage,str(fanart))
                listitem = xbmcgui.ListItem(name1,thumbnailImage=iconimage)
                url = link
                print ("film LINKI : )",url)
                xbmc.PlayList(1).add(url, listitem)
                xbmc.Player().play(pl)
                # return link.group(1)
            else:
                raise Exception('Unable to resolve 180Upload Link')

        except Exception, e:
            print '**** 180Upload Error occured: %s' % e
            raise
        finally:
            dialog.close()
            
def resolve_vidhog(name,url,iconimage,fanart):
        pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        pl.clear()
        try:
            dialog = xbmcgui.DialogProgress()
            dialog.create('Resolving', 'Resolving VidHog Link...')
            dialog.update(0)
            
            print 'VidHog - Requesting GET URL: %s' % url
            html = net.http_GET(url).content

            dialog.update(50)
            if re.search('This server is in maintenance mode', html):
                print '***** VidHog - Site reported maintenance mode'
                raise Exception('File is currently unavailable on the host')
            if re.search('<b>File Not Found</b>', html):
                print '***** VidHog - File not found'
                raise Exception('File has been deleted')

            filename = re.search('<strong>\(<font color="red">(.+?)</font>\)</strong><br><br>', html).group(1)
            extension = re.search('(\.[^\.]*$)', filename).group(1)
            guid = re.search('http://vidhog.com/(.+)$', url).group(1)
            
            vid_embed_url = 'http://vidhog.com/vidembed-%s%s' % (guid, extension)
            
            request = urllib2.Request(vid_embed_url)
            request.add_header('User-Agent', USER_AGENT)
            request.add_header('Referer', url)
            response = urllib2.urlopen(request)
            redirect_url = re.search('(http://.+?)video', response.geturl()).group(1)
            download_link = redirect_url + filename
            
            dialog.update(100)

            dialog.close()
            addLink(name,download_link,iconimage,fanart)
            listitem = xbmcgui.ListItem(name,thumbnailImage=iconimage)
            url = download_link
            print ("film LINKI : )",url)
            xbmc.PlayList(1).add(url, listitem)
            xbmc.Player().play(pl)
            #return download_link
            
        except Exception, e:
            dialog1 = xbmcgui.Dialog()
            dialog1.ok('error','[UPPERCASE][B]                Sorry but the video is deleted!!![/B][/UPPERCASE]')
            
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

def addLink(name,url,iconimage,fanart):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty('fanart_image', fanart)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok

def addDir(name,url,mode,iconimage,fanart):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty('fanart_image', fanart)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

params=get_params()
url=None
name=None
mode=None
iconimage=None
imdb=None
plot=None
fanart=None

try:
        url=urllib.unquote_plus(params['url'])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:
        imdb=int(params["imdb"])
except:
        pass
try:
        plot=urllib.unquote_plus(params["plot"])
except:
        pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)

if mode==None or url==None or len(url)<1:
        print ""
        CATEGORIES()
       
elif mode==1:
        #INDEX_NAVI(url)
        index_test(url)

elif mode==2:
        INDEX_OASE(url)

elif mode==3:
        PLAYLINK_NAVI(url,name,iconimage,fanart) 
        
elif mode==4:
        PLAYLINK_OASE(url,name,iconimage,fanart)

elif mode==5:
        #VIDEOLINKS_NAVI(url)
        index_test(url)
        
elif mode==6:
        if url !=None:
            VIDEOLINKS_OASE(name,url)
        else:
            VIDEOLINKS_OASE(name,'')
            
elif mode==10:
        if 'vidhog' in url:
            resolve_vidhog(name,url,iconimage,fanart)
        elif 'mightyupload' in url:
            resolve_mightyupload(name,url,iconimage,fanart)
        elif 'hugefiles' in url:
            resolve_hugefiles(name,url,iconimage,fanart)
        else:
            resolve_180upload(name,url,iconimage,fanart)
        
elif mode==16:
        SEARCH_OASE(url)
        
xbmcplugin.endOfDirectory(int(sys.argv[1]))
