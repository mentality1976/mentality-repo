#!/usr/bin/python
# -*- coding: iso-8859-1 -*-

import sys
import mechanize
import urllib2,urllib,re,os
import xbmcplugin,xbmcgui
import xbmcaddon,xbmc
from BeautifulSoup import BeautifulSoup as BS
br1 = mechanize.Browser()

url_start='http://evonic.tv/forum/content.php'
def br():
        USER_AGENT = "Mozilla/5.0 (X11; Linux x86_64; rv:10.0.1)"
        " Gecko/20100101 Firefox/10.0.1"
        __settings__ = xbmcaddon.Addon(id="plugin.video.Evonic")
        login= __settings__.getSetting("login")
        password= __settings__.getSetting("password")
        if not login:
                __settings__.openSettings()
        else:
                pass
        br = mechanize.Browser()
        br.set_handle_robots( False )
        br.addheaders = [('User-agent', 'Firefox')]
        br.open(url_start)
        br.select_form(nr=0)
        br["vb_login_username"] = login
        br["vb_login_password"] = password
        response1 = br.submit()
        fc = response1.read()
        # print fc
        if "Danke" in str(fc):
            print "Succesfully Loged in."
        else:
            __settings__.openSettings()
        return br
        

def INDEX_GENRE(url,br):
        content = br.open(url)
        data = content.read()
        enter_addDir(' Suche...','http://evonic.tv/forum/content.php?r=1969-Aktuelle-HD-Filme&page=','',2,'','','','')
        enter_addDir(' Neueinsteiger',url,'',5,'','','','')
        enter_addDir(' 3D Filme','http://evonic.tv/forum/content.php?r=4225-3d-filme','',5,'','','','')
        enter_addDir(' HD Filme','http://evonic.tv/forum/content.php?r=1669-hd-filme','',5,'','','','')
        enter_addDir(' HD Collection','http://evonic.tv/forum/content.php?r=3501-hd-collection','',5,'','','','')
        enter_addDir(' HD Serien','http://evonic.tv/forum/content.php?r=5993-Serien','',5,'','','','')
        enter_addDir(' Aktuelle HD Filme','http://evonic.tv/forum/content.php?r=3938-Aktuelle-HD-Filme','',5,'','','','')
        enter_addDir(' 3D Charts','http://evonic.tv/forum/content.php?r=5440-3d-charts','',5,'','','','')
        enter_addDir(' HD Charts','http://evonic.tv/forum/content.php?r=1989-HD-Charts','',5,'','','','')
        enter_addDir(' Serien Charts','http://evonic.tv/forum/content.php?r=1997-serien-charts','',5,'','','','')
        enter_addDir(' Cineline','http://evonic.tv/forum/list.php?r=category/169','',5,'','','','')
        enter_addDir(' IMDB Ranking',url_start,'',11,'','','','')
        enter_addDir(' HD Genres',url_start,'',10,'','','','')
        enter_addDir(' Century',url_start,'',8,'','','','')
        
def HD_GENRES(url,br):
        content = br.open(url)
        data = content.read()
        match=re.compile('<div class="cat_main_menuitem">\n<a href="(.*?)">HD:(.*?)</a>\n</div>').findall(data)
        for url,name in match:
            enter_addDir(str(name.decode('iso-8859-1').encode('utf-8')),url,'',5,'','','','')
        xbmc.executebuiltin("Container.SetViewMode(300)")
        
def INDEX_IMDB(url,br):
        content = br.open(url)
        data = content.read()
        match=re.compile('<div class="cat_main_menuitem">\n<a href="(.*?)">IMDB(.*?)</a>\n</div>').findall(data)
        for url,name in match:
            enter_addDir('IMDB'+str(name),url,'',5,'','','','')
        xbmc.executebuiltin("Container.SetViewMode(300)")
        
def INDEX_CENTURY(url,br):
        content = br.open(url)
        data = content.read()
        match=re.compile('<div class="cat_main_menuitem">\n<a href="(.*?)">(Jahr.*?)</a>\n</div>').findall(data)
        for url,name in match:
            enter_addDir(str(name),url,'',5,'','','','')
        xbmc.executebuiltin("Container.SetViewMode(300)")
        
def INDEX(url,name,br):
        content = br.open(url)
        data = content.read()
        if 'Collection' in name:
            value=[]
            link=data
            soup = BS(link.decode('iso-8859-1','ignore'))
            for div in soup.findAll('div',  {"class": "article_preview"},smartQuotesTo=None):
                attr= div.findAll('a')
                attribute=[]
                for i in attr:
                    attribute.append(i.string) 
                name= div.find('span').find(text=True)
                name=name.encode('utf-8')###neu
                url= div.find('a')['href']
                url= url.encode('utf-8')###neu
                resim=div.find('img')['src']
                try:
                    value.append((str(name),resim,url,(attribute[2].replace("IMDB ",""))))
                except:
                    value.append((str(name),resim,url,''))
            for name, resim, url, imdb in value:
                enter_addDir(str(name+'[CR][I]imdb-'+str(imdb)+'[/I]'),url,'',7,resim,imdb,'','')
            match=re.compile('title="(.*?)">\r\n\t\t(.*?)\r').findall(data)
            for name, zahl in match:
                enter_addDir('Collections '+str(name),'http://evonic.tv/forum/content.php?r=3501-hd-collection&page='+str(zahl),'',5,'','','','')

        else:
            value=[]
            link=data
            ##print link
            soup = BS(link.decode('iso-8859-1','ignore'))
            for div in soup.findAll('div',  {"class": "article_preview"},smartQuotesTo=None):
                attr= div.findAll('a')
                attribute=[]
                for i in attr:
                    attribute.append(i.string) 
                name= div.find('span').find(text=True)
                name=name.encode('utf-8')###neu
                url= div.find('a')['href']
                url= url.encode('utf-8')###neu
                resim=div.find('img')['src']
                try:
                    value.append((str(name),resim,url,(attribute[2].replace("IMDB ",""))))
                except:
                    value.append((str(name),resim,url,''))
            for name, resim, url, imdb in value:
                collection = ( "Saga","Trilogie","Collection","Trilogy","Quadrologie","Quadrilogy","Anthologie" )
                col = None
                for i in collection:
                    if i in name:
                        enter_addDir(str(name+'[CR][I]imdb-'+str(imdb)+'[/I]'),url,'',7,resim,imdb,'','')
                        col = i
                if col !=None:
                    pass
                elif 'HD:' in name:
                    enter_addDir(str(name+'[CR][I]imdb-'+str(imdb)+'[/I]'),url,'',6,resim,str(imdb),'','')
                elif '3D' in name:
                    enter_addDir(str(name+'[CR][I]imdb-'+str(imdb)+'[/I]'),url,'',6,resim,str(imdb),'','')
                else:
                    enter_addDir(str(name+'[CR][I]Serie[/I]'),url,'',10,resim,str(imdb),'','')
                    
            match=re.compile('<span><a href="(.*?)" title="(.*?)">').findall(data)
            for url1,name1 in match:
                try:
                    token=re.search('&(.*?)page=', url1).group(1)
                    url1 = url1.replace(token, "")
                except:
                    pass
                enter_addDir(name1,url1,'',5,'','','','')
        xbmc.executebuiltin("Container.SetViewMode(500)")

def SEARCH(url1,br):
        kb = xbmc.Keyboard('', 'Search Evonic.tv', False)
        kb.doModal()
        search = kb.getText()
        search=search.decode('utf-8').encode('iso-8859-1')
        main_url=br.open('http://evonic.tv/forum/content.php').read()
        token = re.search('var SECURITYTOKEN = "(.+?)"',main_url).group(1)
        data = {
            'do' : 'search',
            'do' : 'search',
            'lsawithword' : '1',
            'lsatype' : '0',
            'lsazone' : '',
            'lsasort' : 'lastpost',
            'lsasorttype' : 'DESC',
            'keyword' : search,
            'securitytoken' : token,
            's' : ''
            }
        url = 'http://evonic.tv/forum/ajaxlivesearch.php?'
        suche = br.open(url, urllib.urlencode( data)).read()
        match = re.compile('<span><a href=".*?" title="Stream">Stream</a></span>\r*\n*\r*\n*\s*<a href=".*?" title="Zum ersten ungelesenen Beitrag im Thema \'(.*?)\' gehen">.*?</a>.*?<a href="(.*?)" title=".*?">.*?<span class="highlight">.*?</span>.*?</a>').findall(suche)
        value=[]
        for name,url in match:
            enter_addDir(name.decode('iso-8859-1').encode('utf-8'),url.replace("&amp;","&"),'',13,'','','','')
        xbmc.executebuiltin("Container.SetViewMode(400)")

def MANAGE_SEARCH(url,name,br):
        content = br.open(url).read()
        link = re.search('<meta http-equiv="refresh" content="0; URL=(.*?)">',content).group(1)
        collection = ( "Saga","Trilogie","Collection","Trilogy","Quadrologie","Quadrilogy","Anthologie" )
        col = None
        for i in collection:
            if i in name:
                LINKS_COLLECTIONS(link,br)
                col = i
        if col !=None:
            pass
        else:
            VIDEOLINKS(link,name,'','',br)

def VIDEOLINKS(url,name,thumbnail,imdb,br):
        content = br.open(url)
        data = content.read()
        soup = BS(data.decode('iso-8859-1','ignore'))
        try:
            status = re.search('Status:</span> &nbsp; <span style="color: #FF6600;">(.*?)</span>', data).group(1)
            if status == 'Premium Member':
                try:
                    match=re.compile('<a href="(.*?)" target="Videoframe">.*?HD(.*?)</.*?>').findall(data)
                except:
                        pass
                if match == []:
                    try:
                        match=re.compile('<a href="(.*?)" target=".*?"><b><span style=".*?">(.*?)</span>').findall(data)
                    except:
                            pass
                plot=''
                mpaa=''
                thumbnail = thumbnail
                link_name = ''
                link_name1=''
                tmp_url = ''
                for div in soup.findAll('div',  {"class": "quote_container"}):
                    plot = str(div(text=True)[1])
                try:
                    for div in soup.findAll('div',  {"class": "article cms_clear restore postcontainer"}):
                        mpaa = str(div(text=True))
                        mpaa= re.search("FSK:(.*?),",mpaa).group(1)
                except:
                        pass
                nr=0
                for i, e in match:
                    if 'Premium-Member' in i:
                        tmp_url = tmp_url + str(i)
                        link_name = (name+' [I](HD'+e+')[/I]')
                    elif 'Non-Premium-Member' in i:
                        link_name = 'Kein Premium Mitglied'
                    else:
                            pass
                    if link_name !='':
                        try:
                            try:
                                nr_vor = re.search('(\d\d\.)\s*.*?',e).group(1)
                                staffel_vor = re.search('.*\?mov=(\w+)(\d+)-.*?',i)
                            except:
                                nr_vor = None
                            if 'Staffel' not in name:
                                if staffel_vor != None and nr_vor != None:
                                    if '01.' == str(nr_vor):
                                        nr=nr+1
                                        try:
                                            enter_addDir('Staffel '+str(staffel_vor.group(2)),url,url,6,thumbnail,imdb,'','')
                                        except:
                                            enter_addDir('Staffel '+str(staffel_vor.group(2)),url,'',6,'','','','')
                            else:
                                staff = re.search('Staffel (\d+)', name).group(1)
                                if nr_vor != None and staff in staffel_vor.group(1)+staffel_vor.group(2):
                                    if '01.' == str(nr_vor):
                                        nr=nr+1
                                    try:
                                        enter_addDir(e.decode('iso-8859-1').encode('utf-8'),tmp_url,url,3,thumbnail,'','','')
                                    except:
                                        enter_addDir(e.decode('iso-8859-1').encode('utf-8'),tmp_url,url,3,'','','','')
                            tmp_url = ''
                            link_name = ''
                        except:#nr=0
                            try:
                                nr_vor = re.search('(.*?\.) .*?',e).group(1)
                            except:
                                nr_vor = None
                            if nr_vor != None:
                                if '01.'  == str(nr_vor):
                                    nr=nr+1
                                enter_addDir(e.decode('iso-8859-1').encode('utf-8'),tmp_url,url,3,thumbnail,'','','')
                            else:
                                try:
                                    enter_addDir(link_name,tmp_url,url,3,thumbnail,imdb,plot,mpaa)
                                except:
                                    enter_addDir('Dieser'+link_name,tmp_url,url,3,'','','','')
                            tmp_url = ''
                            link_name = ''
                    else:
                            pass
                    tmp_url1=''
                    if 'Free-Member' in i:
                        tmp_url1 = tmp_url1 + str(i)
                        link_name1 = (name+' [I](HD'+e+')[/I]')
                    else:
                            pass
                    if link_name1 !='':
                        try:
                            enter_addDir(link_name1,tmp_url1,url,1,thumbnail,imdb,plot,mpaa) 
                            tmp_url1=''
                            link_name1=''
                        except:
                            enter_addDir(link_name1,tmp_url1,url,1,'','','','')
                            tmp_url1=''
                            link_name1=''
                    else:
                            pass
        except:
                raise
                
        if 'Staffel' not in name:
            try:
                for object in soup.findAll('object', {"class": "restrain"},smartQuotesTo=None):
                    code=re.search("http://www.youtube.com/v/(.*?)&fs=1", str(object.find('param')['value'])).group(1)
                    url='plugin://plugin.video.youtube/?action=play_video&videoid=' + str(code)+"&hd=1"
                    enter_addDir('(Trailer) '+name,str(url),'',12,thumbnail,'','','')
            except:
                    pass
        xbmc.executebuiltin("Container.SetViewMode(400)")
     
def play_trailer(url,name,thumbnail):
        pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        pl.clear()
        enter_addLink(name,url,thumbnail,'','')
        listitem = xbmcgui.ListItem(name,thumbnailImage=thumbnail)
        xbmc.PlayList(1).add(url, listitem)
        xbmc.Player().play(pl) 
        
def play_premium_video(url,name,thumbnail,imdb,mpaa,br):
        pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        pl.clear()
        try:
            dir_vid = br.open(url)
            video = dir_vid.read()
            video_match = re.compile('src="(.*?)"').findall(video)
            link = video_match[0]
            enter_addLink(name,link,thumbnail,imdb,'')
            listitem = xbmcgui.ListItem(name,thumbnailImage=thumbnail)
            xbmc.PlayList(1).add(link, listitem)
            xbmc.Player().play(pl) 
        except:
                pass
                
def play_free_video(url,name,thumbnail,imdb,mpaa,br):
        pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        pl.clear()
        try:
            dir_vid = br.open(url)
            video1 = dir_vid.read()
            video_match1 = re.compile('src="(.*?)" type="video/mp4"').findall(video1)
            link = video_match1[0]
            enter_addLink(name,link,thumbnail,imdb,'')
            listitem = xbmcgui.ListItem(name,thumbnailImage=thumbnail)
            xbmc.PlayList(1).add(link, listitem)
            xbmc.Player().play(pl) 
        except:
                pass

def LINKS_COLLECTIONS(url,br):
        content = br.open(url)
        data = content.read()
        data = (data.decode('iso-8859-1').encode('utf-8')).replace('&amp;','&')
        match=re.compile('<a href="(.*?)" target=".*?">').findall(data)
        match1=re.compile('<*b*>*<font size=".*?">(.*?)</font><*/*b*>*<br />').findall(data)
        match2=re.compile('\r\n<.*?>\r*\n*(.*?)<*b*r*\s*/*>*\r*\n*\s*<div style=".*?">').findall(data)
        if match1:
            match_name = match1
        elif match2:
            match_name = match2
        
        soup = BS(data.decode('iso-8859-1','ignore'))
        value=[]
        for index, div in enumerate(soup.findAll('div',  {"class": "alt2"},smartQuotesTo=None)):
            try:
                img= div.find('img')['src']
                value.append(img)
            except:
                    pass
            if 'none;">Platzhalter</div>' in str(div):
                del match_name[index]
        match_video_HDPlus=[]
        match_video_Free=[]
        free = 0
        plus = 0
        try:
            status = re.search('Status:</span> &nbsp; <span style="color: #FF6600;">(.*?)</span>', data).group(1)
            if status == 'Premium Member':
                for index, i in enumerate(match):
                    # print ("Free: ",free)
                    # print ("Plus: ",plus)
                    tmp_url = ''
                    if 'Premium-Member' in i:
                        if plus==free:
                            plus=plus+1
                        elif plus<free+1:
                            plus=plus+1
                        elif plus==free+1:
                            free=free+1
                            plus=plus+1
                        elif plus==free+2:
                            free=free+3
                            plus=plus+1
                        tmp_url = tmp_url + str(i)
                        try:
                            enter_addDir(match_name[plus-1]+'[CR] [I](HD Plus)[/I]',tmp_url,url,3,value[plus-1],'','','')
                        except:
                                pass
                    elif 'Free-Member' in i:
                        if free==plus:
                            free=free+1
                        elif free<plus+1:
                            free=free+1
                        elif free==plus+1:
                            plus=plus+1
                            free=free+1
                        elif free==plus+2:
                            plus=plus+3
                            free=free+1
                        tmp_url = tmp_url + str(i)
                        match_video_Free.append(tmp_url)
                        try:
                            enter_addDir(match_name[free-1]+'[CR] [I](HD Free)[/I]',tmp_url,url,1,value[free-1],'','','')
                        except:
                            #enter_addLink('Ueberlastet'+match_name[free],i,'','','')
                            pass
        except:
                pass
        xbmc.executebuiltin("Container.SetViewMode(500)")

def write_attr(url):
        content = br.open(url)
        data = content.read()
        link=data.replace('\xf6',"oe").replace('&amp;',"&").replace('\xd6',"Oe").replace('\xdc',"Ue").replace('\xfc',"ue").replace('\xc4',"Ae").replace('\xe4',"ae").replace('\xdd',"I").replace('\xfd',"i").replace('\xe7',"c").replace('\xde',"s").replace('\xfe',"s").replace('\xc7',"c").replace('\xf0',"g").replace('\xdf',"ss").replace('\xe9',"e")
        value=[]
        soup = BS(link)
        for ol in soup.findAll('ol',  {"class": "commalist"},smartQuotesTo=None):
            attr= ol.findAll('a')
            attribute=[]
            for i in attr:
                attribute.append(i.string)
            value.append(attribute)
        return value
        
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
        return param
        
def enter_addLink(name,url,iconimage,imdb,plot):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Rating": imdb, "Plot": plot, "MPAA": imdb } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok

def enter_addDir(name,url,url0,mode,iconimage,imdb,plot,mpaa):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&url0="+urllib.quote_plus(url0)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&imdb="+str(imdb)+"&mpaa="+str(mpaa)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name,"Rating": imdb, "Plot": plot, "MPAA": mpaa } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

