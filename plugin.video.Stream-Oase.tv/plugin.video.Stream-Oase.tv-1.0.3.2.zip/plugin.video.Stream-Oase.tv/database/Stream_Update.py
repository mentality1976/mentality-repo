# -*- coding: utf-8 -*-
import urllib2,re,os,sys
from BeautifulSoup import BeautifulSoup as BS
from xml.dom.minidom import Document
import mechanize,gzip,shutil
import xbmcaddon,xbmc,xbmcgui
addon_id = 'plugin.video.Stream-Oase.tv'
addon = xbmcaddon.Addon(addon_id)
__settings__ = xbmcaddon.Addon(id="plugin.video.Stream-Oase.tv")
status = __settings__.getSetting("status")
datapath = __settings__.getAddonInfo('path')
channels = xbmc.translatePath(os.path.join(datapath, 'resources', 'lib'))
sys.path.append(channels)
channels = xbmc.translatePath(os.path.join(datapath, 'database'))
sys.path.append(channels)

def hazirla(isim,bolum):
    try:
        sonuclar=[]
        if 'New' in isim:
                tmp = []
                for f in VIDEOLINKS_OASE(isim,bolum):
                        #
                        str(f)
                        tmp.append(f)
                for i in reversed(tmp):
                        sonuclar.append(i)
        else:
                sayfa = sayfalama(bolum)
                for i in sayfa:
                        for f in VIDEOLINKS_OASE(isim,i):
                            sonuclar.append(f)
    except:
            pass
    if sonuclar:
        xml_yap(isim,sonuclar)
    if len(sonuclar) > 0:
        dialog1 = xbmcgui.Dialog()
        dialog1.ok('Datenbank Update der Kategorie '+isim+' beendet!','[UPPERCASE][B]Es wurden '+str(len(sonuclar))+' Filme in '+isim+' hinzugefuegt[/B][/UPPERCASE]','Damit die Filme sichtbar werden, raus und rein!')
    print 'bitti'
    __settings__.setSetting(str(isim.decode('latin1').encode('utf-8')), 'false')
                    
def VIDEOLINKS_OASE(name1,url):
        link=get_url(url)
        soup = BS(link)
        value=[]
        value2=[]
        video_db = gzip.open(  os.path.join(channels, name1+'.xml.gz'),"r")
        video_db_str = video_db.read().decode('utf-8')
        video_db.close()
        #print video_db_str
        for div in soup.find('div',  {"class": "sp-component-area-inner clearfix"},smartQuotesTo=None).findAll('div',  {"class": "avs_thumb"},smartQuotesTo=None):
                url= div.find('a')['href']
                img= div.find('img').findNext('img')['src']
                name= (div.find('span').text).replace("&amp;","&")
                if name in video_db_str:
                    pass
                else:
                    #print name
                    value.append((url, img, name))
        if name1=='New Videos':
            for url1,thumbnail,name in value:
                try:
                        #print name
                        value2.append(PLAYLINK_OASE(url1,name,thumbnail))
                except:
                        print 'hata1'
        else:
            for url1,thumbnail,name in value:
                try:
                        #print name
                        value2.append(PLAYLINK_OASE(url1,name,thumbnail))
                except:
                        print 'hata2'
        return value2
        
def sayfalama(url_base):
        link=get_url(url_base)
        soup = BS(link)
        seiten = []
        seiten.append(url_base)
        for div in soup.find('div',  {"class": "sp-component-area-inner clearfix"},smartQuotesTo=None).findAll('li',smartQuotesTo=None):
                try:
                    url= div.find('a')['href']
                except:
                    url=""
                    
                name= div.find('a').find(text=True)
                if name != '1' and name!= 'Weiter' and name!='Ende':
                        seiten.append('http://stream-oase.tv'+url)
                
        return seiten
        
def PLAYLINK_OASE(url,name,iconimage):
        nuna='http://stream-oase.tv'+url
        link=get_url(nuna)
        match=re.compile('<iframe src="(.*?)embed-(.*?)-.*?.html" frameborder=', re.I).findall(link)
        match2=re.compile('<iframe src="(.*?)" frameborder=', re.I).findall(link)
        try:
            fanart = get_fanart(name)
        except:
            fanart = ''
        try:
            imdb = re.search('<p><strong>imdb-Bewertung:</strong> (.*?)/10<.*?', link).group(1).decode('utf-8')
            imdb = imdb.replace(",",".")
        except:
            imdb = ''
        try:
            darsteller = re.search('>Darsteller:</strong>(.*?)<.*?',link).group(1).encode('utf-8')
##            print darsteller
        except:
            darsteller = ''
        try:
            plot = re.search('<strong>Inhalt:</strong>\s*</p>\r\n<p>(.*?)<.*?', link).group(1).decode('utf-8')
##            print plot
        except:
            plot = ''
        try:
            fsk = re.search('<p><strong>FSK:</strong> (.*?)</p>', link).group(1).encode('utf-8')
        except:
            fsk = ''
        try:
            code1 = re.search('http://www.imdb.com/title/(.*?)/', link).group(1).decode('utf8')
        except:
            code1 = ''
        direct_links = []
        for hoster, code in match:
                if not('mightyupload' in hoster):
                    try:
                            direct_links.append(str(hoster)+str(code))
                                    
                    except:
                            pass
        for src in match2:
            if 'mightyupload' in src:
                    try:
                            ref = re.search('http://(.*?)/',src).group(1)
                            ref = ref.replace("www.", '').replace(".com",'').replace(".net",'')
                            direct_links.append(src)
                    except:
                            pass
        return(name,(direct_links),iconimage,fanart,imdb,darsteller,plot,fsk,code1)
                        
def get_fanart(name):
        try:
            reg = re.search('(?<=) - .+', name).group(0)
            name = name.replace(reg,"")
        except:
                pass
        try:
            reg = re.search('(?<=) \(\d+\)', name).group(0)
            name = name.replace(reg,"")
        except:
                pass
        try:
            reg = re.search('(?<=)\s*20\d+', name).group(0)
            name = name.replace(reg,"")
        except:
                pass
        try:
            reg = re.search('(?<=)\s*UNCUT', name).group(0)
            name = name.replace(reg,"")
        except:
                pass
        try:
            name = name.replace("�".decode('latin1'),"ue").replace("�".decode('latin1'),"oe").replace("�".decode('latin1'),"ae").replace("�".decode('latin1'),"ss")
        except:
                pass
        print str(name)
        url='http://www.themoviedb.org'
        br = mechanize.Browser()
        br.open(url)
        br.select_form(nr=0)
        br["query"] = name
        response = br.submit()
        link = response.read()
        response.close()
        soup = BS(link)
        video = soup.find('ul', {"class": "search_results movie"}).find('a')['href']
        req = urllib2.urlopen(url+video)
        link = req.read()
        soup2 = BS(link)
        img = (soup2.find('div', {"id": "images"}).find('img')['src']).replace("w300","original")
        return img

def get_url(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        return link
def xml_yap(isim,sonuclar):###xml yapim yeri
        doc = Document()
        liste = doc.createElement("channel")
        doc.appendChild(liste)

        for videoTitle,url,thumbnail,fanart,imdb,darsteller,plot,fsk,code in sonuclar:
            kanal = doc.createElement("item")
            liste.appendChild(kanal)
            
            ad = doc.createElement("title")
            kanal.appendChild(ad)
            veri_ad = doc.createTextNode(videoTitle)
            ad.appendChild(veri_ad)
            a=1
            for i in url:
                    adres = doc.createElement("link"+str(a))
                    kanal.appendChild(adres)
                    veri_adres = doc.createTextNode(i)
                    adres.appendChild(veri_adres)
                    a+=1

            resim = doc.createElement("thumbnail")
            kanal.appendChild(resim)
            veri_resim = doc.createTextNode(thumbnail)
            resim.appendChild(veri_resim)
            
            fanar = doc.createElement("fanart")
            kanal.appendChild(fanar)
            veri_fanar = doc.createTextNode(fanart)
            fanar.appendChild(veri_fanar)
            
            d_imdb = doc.createElement("imdb")
            kanal.appendChild(d_imdb)
            veri_imdb = doc.createTextNode(imdb)
            d_imdb.appendChild(veri_imdb)
            
            d_darsteller = doc.createElement("darsteller")
            kanal.appendChild(d_darsteller)
            veri_darsteller = doc.createTextNode(darsteller)
            d_darsteller.appendChild(veri_darsteller)
            
            d_plot = doc.createElement("plot")
            kanal.appendChild(d_plot)
            veri_plot = doc.createTextNode(plot)
            d_plot.appendChild(veri_plot)
            
            d_fsk = doc.createElement("fsk")
            kanal.appendChild(d_fsk)
            veri_fsk = doc.createTextNode(fsk)
            d_fsk.appendChild(veri_fsk)
            
            d_code = doc.createElement("code")
            kanal.appendChild(d_code)
            veri_code = doc.createTextNode(code)
            d_code.appendChild(veri_code)

        filepath = isim+'.xml.gz'
        
        f = gzip.open(  os.path.join(channels, isim+'.xml.gz'),"ab")
        f.write((doc.toprettyxml(encoding="utf-8")).replace("&amp;","&"))
        f.close()
        #return filepath

# hazirla('Action', 'http://stream-oase.tv/index.php/hd-oase/category/action')
