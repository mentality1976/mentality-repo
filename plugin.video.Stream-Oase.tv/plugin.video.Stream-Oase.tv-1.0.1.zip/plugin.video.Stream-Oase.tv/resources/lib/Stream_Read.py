# -*- coding: utf-8 -*-
import urllib2,re,os,sys
from BeautifulSoup import BeautifulSoup as BS
from xml.dom.minidom import Document
import mechanize,gzip


def INDEX_OASE():
        url='http://stream-oase.tv/index.php/hd-oase'
        link=get_url(url)
        soup = BS(link)
        value=[]
        hazirla('New Videos','http://stream-oase.tv/index.php/hd-oase/video/latest')
        for div in soup.find('div',  {"class": "mod-wrapper-menu clearfix"},smartQuotesTo=None).findAll('div',  {"class": "avs_thumb"},smartQuotesTo=None):
            url= div.find('a')['href']
            img= div.find('img').findNext('img')['src']
            name= (div.find('span').text)
            #hazirla(name,'http://stream-oase.tv'+url)

def hazirla(isim1,bolum):
    sonuclar=[]
    isim = isim1.encode('utf-8').replace("Kom�die","Komodie").replace("Doku�s","Dokus")
    if 'New' in isim:
            for f in VIDEOLINKS_OASE(isim,bolum):
                    print f
                    sonuclar.append(f)
    else:
            sayfa = sayfalama(bolum)
            for i in sayfa:
                    for f in VIDEOLINKS_OASE(isim,i):
                        sonuclar.append(f)
                        print f
    xml_yap(isim,sonuclar)
    print 'bitti'
                    
def VIDEOLINKS_OASE(name1,url):
        link=get_url(url)
        soup = BS(link)
        value=[]
        value2=[]
        for div in soup.find('div',  {"class": "sp-component-area-inner clearfix"},smartQuotesTo=None).findAll('div',  {"class": "avs_thumb"},smartQuotesTo=None):
                url= div.find('a')['href']
                img= div.find('img').findNext('img')['src']
                name= (div.find('span').text).replace("&amp;","&")
                value.append((url, img, name))
        if name1=='New Videos':
            for url1,thumbnail,name in value:
                try:
                        #print name
                        value2.append(PLAYLINK_OASE(url1,name,thumbnail))
                except:
                        print 'hata1'
        else:
            for url1,thumbnail,name in value:
                try:
                        #print name
                        value2.append(PLAYLINK_OASE(url1,name,thumbnail))
                except:
                        print 'hata2'
        return value2
        
def sayfalama(url_base):
        link=get_url(url_base)
        soup = BS(link)
        seiten = []
        seiten.append(url_base)
        for div in soup.find('div',  {"class": "sp-component-area-inner clearfix"},smartQuotesTo=None).findAll('li',smartQuotesTo=None):
                try:
                    url= div.find('a')['href']
                except:
                    url=""
                    
                name= div.find('a').find(text=True)
                if name != '1' and name!= 'Weiter' and name!='Ende':
                        seiten.append('http://stream-oase.tv'+url)
                
        return seiten
        
def PLAYLINK_OASE(url,name,iconimage):
        nuna='http://stream-oase.tv'+url
        link=get_url(nuna)
        match=re.compile('<iframe src="(.*?)embed-(.*?)-.*?.html" frameborder=', re.I).findall(link)
        match2=re.compile('<iframe src="(.*?)" frameborder=', re.I).findall(link)
        try:
            fanart = get_fanart(name)
        except:
            fanart = ''
        direct_links = []
        for hoster, code in match:
                if not('mightyupload' in hoster):
                    try:
                            direct_links.append(str(hoster)+str(code))
                                    
                    except:
                            pass
        for src in match2:
            if 'mightyupload' in src:
                    try:
                            ref = re.search('http://(.*?)/',src).group(1)
                            ref = ref.replace("www.", '').replace(".com",'').replace(".net",'')
                            direct_links.append(src)
                    except:
                            pass
        return(name,(direct_links),iconimage,fanart)
                        
def get_fanart(name):
        url='http://www.themoviedb.org'
        br = mechanize.Browser()
        br.open(url)
        br.select_form(nr=0)
        br["query"] = name
        response = br.submit()
        link = response.read()
        response.close()
        soup = BS(link)
        video = soup.find('ul', {"class": "search_results movie"}).find('a')['href']
        req = urllib2.urlopen(url+video)
        link = req.read()
        soup2 = BS(link)
        img = (soup2.find('div', {"id": "images"}).find('img')['src']).replace("w300","original")
        return img

def get_url(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        return link
def xml_yap(isim,sonuclar):###xml yapim yeri
        doc = Document()
        liste = doc.createElement("channel")
        doc.appendChild(liste)

        for videoTitle,url,thumbnail,fanart in sonuclar:
            kanal = doc.createElement("item")
            liste.appendChild(kanal)
            
            ad = doc.createElement("title")
            kanal.appendChild(ad)
            veri_ad = doc.createTextNode(videoTitle)
            ad.appendChild(veri_ad)
            a=1
            for i in url:
                    adres = doc.createElement("link"+str(a))
                    kanal.appendChild(adres)
                    veri_adres = doc.createTextNode(i)
                    adres.appendChild(veri_adres)
                    a+=1

            resim = doc.createElement("thumbnail")
            kanal.appendChild(resim)
            veri_resim = doc.createTextNode(thumbnail)
            resim.appendChild(veri_resim)
            
            resim = doc.createElement("fanart")
            kanal.appendChild(resim)
            veri_resim = doc.createTextNode(fanart)
            resim.appendChild(veri_resim)

        filepath = datapath+'\\database\\'+isim+'.xml.gz'
        try:
            f = gzip.open(filepath, "a")
        except:
            f = gzip.open(filepath, "wb")
        try:
            f.write((doc.toprettyxml(indent="", encoding="utf-8")).replace("&amp;","&"))
        finally:
            f.close()
        #return filepath

