#!/usr/bin/python
# -*- coding: utf-8 -*-
# Coded by Mentality
import urllib,urllib2,re,os,sys,xbmcplugin,xbmcgui,xbmc,xbmcaddon,errno,time
from BeautifulSoup import BeautifulSoup as BS
import HTMLParser
html_parser = HTMLParser.HTMLParser()
opener = urllib2.build_opener()
addon_id = 'plugin.audio.mp3indirdur'
addon = xbmcaddon.Addon(addon_id)
__settings__ = xbmcaddon.Addon(addon_id)
al_folder = __settings__.getSetting("al_folder")
so_folder = __settings__.getSetting("so_folder")
pls_folder = __settings__.getSetting("pls_folder")
pls_file = __settings__.getSetting("pls_file")
datapath = __settings__.getAddonInfo('path')
channels1 = xbmc.translatePath(os.path.join(datapath, 'resources', 'images'))
sys.path.append(channels1)
def CATEGORIES(url):
        addDir('TÜRKÇE ŞARKILAR','http://www.mp3indirdur.com/turkce-mp3ler.asp',1,'',2)
        addDir('YABANCI ŞARKILAR','http://www.mp3indirdur.com/yabanci-mp3ler.asp',1,'',2)
        addDir('SANATÇILAR','http://www.mp3indirdur.com/sanatcilar.asp',1,'',4)
        addDir('YENİ MP3LER','http://www.mp3indirdur.com/yeni-mp3ler.asp',2,'',None)
        addDir('HİT MP3LER','http://www.mp3indirdur.com/hit-mp3ler.asp',2,'',None)
        addDir('YENİ ALBÜMLER','http://www.mp3indirdur.com/yeni-albumler.asp',7,'',None)
        addDir('[COLOR green]PLAYLISTLERIM[/COLOR]','http://www.mp3indirdur.com/yeni-albumler.asp',15,'',None)
        xbmc.executebuiltin("Container.SetViewMode(400)")

def SEARCH(url):
        kb = xbmc.Keyboard('', 'mp3indirdur', False)
        kb.doModal()
        search = kb.getText()
        search=search.decode('utf-8').encode('iso-8859-1')
        search=urllib.quote(search)
        url_search = 'http://beeg.com/search?q='+search
        INDEX(url_search)

def INDEX(url,modus):
        link = opener.open(url).read()
        soup = BS(link)
        for a in (soup.find('div',  {"class": "alfabeListe"},smartQuotesTo=None)).findAll('a'):
            name = a['title'].encode('utf-8')
            url1 = a['href'].encode('utf-8')
            addDir(name,"http://www.mp3indirdur.com"+url1,int(modus),'','')
        xbmc.executebuiltin("Container.SetViewMode(400)")


def Song_Links(url,name):
        opener.addheaders = [('Referer', url)]
        link = opener.open(url).read()
        soup = BS(link)
        for a in (soup.find('ul',  {"class": "ortaMp3lerListesi"},smartQuotesTo=None)).findAll('a'):
            name1 = (a.find(text=True)).encode('utf-8')
            url1 = a['href'].encode('utf-8')
            meta = get_audio("http://www.mp3indirdur.com"+url1)
            addLink(name1,str(meta['url']),3,meta['image'],meta['album'],meta['artist'],meta['title'],name,url)
        #paging#
        try:
            sayi = len(soup.find('div',  {"class": "sayfalar"},smartQuotesTo=None).findAll('a'))
            print sayi
            if sayi > 1:
                onceki = re.search('href="(.*?)">(Önceki Sayfa)</a>',link)
                #~ print onceki.group(1)
                sonraki = re.search('href="(.*?)">(Sonraki Sayfa)</a>',link)
                try:
                    addDir(onceki.group(2),"http://www.mp3indirdur.com"+onceki.group(1),2,'','')
                except:
                    pass
                try:
                    addDir(sonraki.group(2),"http://www.mp3indirdur.com"+sonraki.group(1),2,'','')
                except:
                    pass
                addDir('Sayfaya git =',url,17,'',sayi-1)
        except:
            pass

def sayfa_git(url,sayi):
        try:
            url=re.search("(http.*?)\&sayfa\=\d*$",url).group(1)
        except:
            pass
        dialog = xbmcgui.Dialog()
        nr = dialog.input("Sayfa numarasini giriniz. "+str(sayi)+" sayfa var", type=xbmcgui.INPUT_NUMERIC)
        if int(nr)<sayi:
            sayfagit = url+"&sayfa="+str(nr)
            print sayfagit
            Song_Links(sayfagit,'')
        else:
            dialog.notification('Sayi hatasi', 'Gecerli sayi vermediniz, bu sayfa yok!')

def Artist_links(url,name):
        opener.addheaders = [('Referer', url)]
        link = opener.open(url).read()
        soup = BS(link)
        for a in (soup.find('ul',  {"class": "ortaSanatciListesi"},smartQuotesTo=None)).findAll('a'):
            name = (a.find(text=True)).encode('utf-8')
            url1 = a['href'].encode('utf-8')
            addDir(name,"http://www.mp3indirdur.com"+url1,5,'','')
        try:
            sayi = len(soup.find('div',  {"class": "sayfalar"},smartQuotesTo=None).findAll('a'))
            print sayi
            if sayi > 1:
                onceki = re.search('href="(.*?)">(Önceki Sayfa)</a>',link)
                #~ print onceki.group(1)
                sonraki = re.search('href="(.*?)">(Sonraki Sayfa)</a>',link)
                try:
                    addDir(onceki.group(2),"http://www.mp3indirdur.com"+onceki.group(1),4,'','')
                except:
                    pass
                try:
                    addDir(sonraki.group(2),"http://www.mp3indirdur.com"+sonraki.group(1),4,'','')
                except:
                    pass
                addDir('Sayfaya git =',url,18,'',sayi-1)
        except:
            pass

def sayfa_git_alb(url,sayi):
        try:
            url=re.search("(http.*?)\&sayfa\=\d*$",url).group(1)
        except:
            pass
        dialog = xbmcgui.Dialog()
        nr = dialog.input("Sayfa numarasini giriniz. "+str(sayi)+" sayfa var", type=xbmcgui.INPUT_NUMERIC)
        if int(nr)<sayi:
            sayfagit = url+"&sayfa="+str(nr)
            print sayfagit
            Artist_links(sayfagit,'')
        else:
            dialog.notification('Sayi hatasi', 'Gecerli sayi vermediniz, bu sayfa yok!')

def secim(name,url):
        opener.addheaders = [('Referer', url)]
        link = opener.open(url).read()
        songs = re.search('<a id="sanatciSarkilari" title=".*?" href="(.*?)">(.*?)</a>\r\n',link)
        albums = re.search('<a id="sanatciAlbumleri" title=".*?" href="(.*?)">(.*?)</a>\r\n',link)
        addDir(songs.group(2),"http://www.mp3indirdur.com"+songs.group(1),2,'','')
        addDir(albums.group(2),"http://www.mp3indirdur.com"+albums.group(1),6,'','')

def album(name,url):
        opener.addheaders = [('Referer', url)]
        link = opener.open(url).read()
        soup = BS(link)
        for div in soup.findAll(attrs={'class':re.compile(r".*\bortaSolAlbumListesi\b.*")}):
            name = div.find('img')['alt'].encode('utf-8')
            img = div.find('img')['src'].encode('utf-8')
            url1 = div.find('a')['href'].encode('utf-8')
            addDir(name,"http://www.mp3indirdur.com/"+url1,2,"http://www.mp3indirdur.com/"+img,'')

def yeni_album(url):
        opener.addheaders = [('Referer', url)]
        link = opener.open(url).read()
        match = re.compile('span class=".*?">.*?</span> <a title=".*?" href=".*?">(.*?)</a> \- <a title=".*?" href="(.*?)">(.*?)</a> <span class="sayiRenk">\(<span title=".*?">.*?</span>\)</span></li>').findall(link)
        for san,link,title in match:
            addDir(san+" - "+title,"http://www.mp3indirdur.com/"+link,2,'','')

def get_audio(web_url):
        req = urllib2.Request(web_url)
        response = urllib2.urlopen(req)
        html=response.read()
        img=re.search('itemprop="photo" src="(.*?)"',html).group(1)
        artist=re.search('Sanatçı</div><div class="detayBilgilerSag">: <a title=".*?" href=".*?">(.*?)</a></div>',html).group(1)
        album=re.search('Albüm</div><div class="detayBilgilerSag renkSira">: <a title=".*?" href=".*?">(.*?)</a></div>',html).group(1)
        title=re.search('Şarkı</div><div class="detayBilgilerSag">: (.*?)</div>',html).group(1)
        headers={'Referer': web_url}
        gelen=re.search('<iframe src="([^"]+)', html)
        htmlweb='http://www.mp3indirdur.com'+gelen.group(1)
        req = urllib2.Request(htmlweb, headers=headers)
        response = urllib2.urlopen(req)
        link=response.read()
        url1=re.search('mp3\s*:\s*\'(.*?)\'', link).group(1)
        return {"url": url1,"artist": artist,"album": album,"title": title,"image": "http://www.mp3indirdur.com"+img}

def mkdir_p(path):
    try:
        os.makedirs(path)
    except OSError as exc: # Python >2.5
        if exc.errno == errno.EEXIST and os.path.isdir(path):
            pass
        else: raise

def AlbumDownloaderClass(url,path,img):
    if __settings__.getSetting("al_folder")=="false":
        select_al_folder()
    mkdir_p(__settings__.getSetting("al_folder")+path)
    opener.addheaders = [('Referer', url)]
    link = opener.open(url).read()
    soup = BS(link)
    for a in (soup.find('ul',  {"class": "ortaMp3lerListesi"},smartQuotesTo=None)).findAll('a'):
        name1 = (a.find(text=True)).encode('utf-8')
        url1 = a['href'].encode('utf-8')
        meta = get_audio("http://www.mp3indirdur.com"+url1)
        #~ addLink(name1,str(meta['url']),3,meta['image'],meta['album'],meta['artist'],meta['title'],name,url)
        dp = xbmcgui.DialogProgressBG()
        dp.create(path,"Downloading "+name1)
        urllib.urlretrieve(str(meta['url']),__settings__.getSetting("al_folder")+path+'/'+name1+'.mp3',lambda nb, bs, fs, url=str(meta['url']): _pbhook(nb,bs,fs,str(meta['url']),dp))

def SongDownloaderClass(url,name):
    if __settings__.getSetting("so_folder")=="false":
        select_so_folder()
    dp = xbmcgui.DialogProgressBG()
    dp.create("Song Download","Downloading "+name)
    urllib.urlretrieve(url,__settings__.getSetting("so_folder")+name+'.mp3',lambda nb, bs, fs, url=url: _pbhook(nb,bs,fs,url,dp))

def _pbhook(numblocks, blocksize, filesize, url=None,dp=None):
    try:
        percent = min((numblocks*blocksize*100)/filesize, 100)
        dp.update(percent)
    except:
        percent = 100
        dp.update(percent)
    if percent==100:
        print "DOWNLOAD FINISHED"
        dp.close()

def create_playlst(name,path):
    output = open(path+name,'w')
    output.write(('#EXTM3U\r\n'))
    output.close()

def select_folder():
    dialog = xbmcgui.Dialog()
    __settings__.setSetting("pls_folder", dialog.browse(3,'Ordner Fuer Playlists aussuchen','files'))

def select_al_folder():
    dialog = xbmcgui.Dialog()
    __settings__.setSetting("al_folder", dialog.browse(3,'Ordner Fuer Playlists aussuchen','files'))

def select_so_folder():
    dialog = xbmcgui.Dialog()
    __settings__.setSetting("so_folder", dialog.browse(3,'Ordner Fuer Playlists aussuchen','files'))

def album2pls(url,name):
    if __settings__.getSetting("pls_folder")=="false":
        select_folder()
    path = __settings__.getSetting("pls_folder")
    output = open(path+name+'.m3u','w')
    output.write(('#EXTM3U\r\n'))
    opener.addheaders = [('Referer', url)]
    link = opener.open(url).read()
    soup = BS(link)
    for a in (soup.find('ul',  {"class": "ortaMp3lerListesi"},smartQuotesTo=None)).findAll('a'):
        name1 = (a.find(text=True)).encode('utf-8')
        url1 = a['href'].encode('utf-8')
        meta = get_audio("http://www.mp3indirdur.com"+url1)
        output.write(('#EXTINF:-1,'+name1+'\r\n'+meta['url']+'\r\n'))
    output.write(('#EXTINF:-1,Cover\r\n"cover": "'+meta['image']+'"'))
    output.close()

def song2pls(url,name):
    if __settings__.getSetting("pls_file")=="false":
        if __settings__.getSetting("pls_folder")=="false":
            dialog = xbmcgui.Dialog()
            __settings__.setSetting("pls_folder", dialog.browse(3,'Ordner Fuer Playlists aussuchen','files'))
            path = __settings__.getSetting("pls_folder")
        else:
            path = __settings__.getSetting("pls_folder")
        if ".m3u" not in str(os.listdir(__settings__.getSetting("pls_folder"))):
            kb = xbmc.Keyboard('', 'Name der neuen Playlist', False)
            kb.doModal()
            plsname = kb.getText()
            if plsname !='':
                create_playlst(plsname+'.m3u',path)
                time.sleep(2)
                __settings__.setSetting("pls_file", path+plsname+'.m3u')
                pls_file1 = __settings__.getSetting("pls_file")
        else:
            select_pls()
            pls_file1 = __settings__.getSetting("pls_file")
        output = open(pls_file1,'a')
        output.write(('#EXTM3U\r\n'))
        output.close()
        output = open(pls_file1,'a')
        output.write('#EXTINF:-1,'+name+'\r\n'+url+'\r\n')
        output.close()

    else:
        if os.path.exists(__settings__.getSetting("pls_file")):
            output = open(__settings__.getSetting("pls_file"),'a')
            output.write('#EXTINF:-1,'+name+'\r\n'+url+'\r\n')
            output.close()
        else:
            kb = xbmc.Keyboard('', 'Name der neuen Playlist', False)
            kb.doModal()
            plsname = kb.getText()
            if plsname !='':
                create_playlst(plsname+'.m3u',__settings__.getSetting("pls_folder"))
                time.sleep(2)
                __settings__.setSetting("pls_file", __settings__.getSetting("pls_folder")+plsname+'.m3u')
                pls_file1 = __settings__.getSetting("pls_file")
                output = open(pls_file1,'a')
                output.write('#EXTINF:-1,'+name+'\r\n'+url+'\r\n')
                output.close()

def select_pls():
    dialog = xbmcgui.Dialog()
    if __settings__.getSetting("pls_folder")=="false":
        select_folder()
    plslists = os.listdir(__settings__.getSetting("pls_folder"))
    liste = []
    for i in plslists:
        try:
            match=re.search('(.*?)\.m3u',i).group(1)
            liste.append(match)
        except:
            pass
    gelen = dialog.select('Eine Playlist aussuchen',liste)
    __settings__.setSetting("pls_file", __settings__.getSetting("pls_folder")+liste[gelen]+'.m3u')

def del_pls():
    dialog = xbmcgui.Dialog()
    if __settings__.getSetting("pls_folder")=='false':
        select_folder()
    plslists = os.listdir(__settings__.getSetting("pls_folder"))
    liste = []
    for i in plslists:
        try:
            match=re.search('(.*?)\.m3u',i).group(1)
            liste.append(match)
        except:
            pass
    gelen = dialog.select('Eine Playlist aussuchen',liste)
    os.remove(__settings__.getSetting("pls_folder")+liste[gelen]+'.m3u')

def index_pls():
    dialog = xbmcgui.Dialog()
    if __settings__.getSetting("pls_folder")=='false':
        select_folder()
    plslists = os.listdir(__settings__.getSetting("pls_folder"))
    for i in plslists:
        if '.m3u' in i:
            addDir((re.search('(.*?)\.m3u',i).group(1)),__settings__.getSetting("pls_folder")+i,16,'','')

def read_m3u(url):
    output = open(url,'r')
    liste = output.readlines()
    playlist = []
    output.close()
    name = None
    url1 = None
    img = ''
    for i in liste:
        if 'Cover' in i or 'EXTM3U' in i:
            pass
        elif 'cover' in i:
            img = i.replace('"cover": ','').replace('"','')
        elif 'EXTINF' in i:
            name = i.replace('#EXTINF:-1,', '').replace('\r\n','')
        elif 'Cover' not in i or 'EXTM3U' not in i:
            url1 = i.replace('\r\n','')
        else:
            pass
        if name!=None and url1!=None:
            playlist.append((name,url1))
            name = None
            url1 = None
    for name, url1 in playlist:
        addLink(name,url1,html_parser.unescape(img),'','','','','','')

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]

        return param

def addLink(name,url,mode,iconimage,album,artist,title,album_name,album_url):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultAudio.png", thumbnailImage=iconimage)
        liz.setInfo( type="Music", infoLabels={ "Album": album, "Artist": artist,"Title": title, } )
        contextMenuItems = []
        contextMenuItems.append(('Album downloaden', 'XBMC.RunPlugin(%s?mode=8&name=%s&url=%s)'% (sys.argv[0], urllib.quote_plus(album_name),urllib.quote_plus(album_url))))
        contextMenuItems.append(('Song downloaden', 'XBMC.RunPlugin(%s?mode=9&name=%s&url=%s)'% (sys.argv[0], urllib.quote_plus(name),urllib.quote_plus(url))))
        if album_name:
            contextMenuItems.append(('add Album to MyLists', 'XBMC.RunPlugin(%s?mode=11&name=%s&url=%s)'% (sys.argv[0], urllib.quote_plus(album_name),urllib.quote_plus(album_url))))
        contextMenuItems.append(('create New Playlist', 'XBMC.RunPlugin(%s?mode=10&name=%s&url=%s)'% (sys.argv[0], urllib.quote_plus(album_name),urllib.quote_plus(album_url))))
        contextMenuItems.append(('add Song to Playlist', 'XBMC.RunPlugin(%s?mode=12&name=%s&url=%s)'% (sys.argv[0], urllib.quote_plus(name),urllib.quote_plus(url))))
        contextMenuItems.append(('Select Playlist', 'XBMC.RunPlugin(%s?mode=13&name=%s&url=%s)'% (sys.argv[0], urllib.quote_plus(name),urllib.quote_plus(url))))
        contextMenuItems.append(('Delete Playlist', 'XBMC.RunPlugin(%s?mode=14&name=%s&url=%s)'% (sys.argv[0], urllib.quote_plus(name),urllib.quote_plus(url))))
        liz.addContextMenuItems(contextMenuItems, replaceItems=True)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok


def addDir(name,url,mode,iconimage,modus):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&modus="+str(modus)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok


params=get_params()
url=None
name=None
mode=None
img=None
modus=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        img=urllib.unquote_plus(params["img"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        modus=int(params["modus"])
except:
        pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "Modus: "+str(modus)

if mode==None or url==None or len(url)<1:
        print ""
        CATEGORIES('http://www.mp3indirdur.com/sanatcilar.asp')

elif mode==1:
        print ""+url
        INDEX(url,modus)

elif mode==2:
        print ""+url
        Song_Links(url,name)

elif mode==3:
        print ""+url
        get_audio(url)

elif mode==4:
        print ""+url
        Artist_links(url,name)

elif mode==5:
        print ""+url
        secim(name,url)

elif mode==6:
        print ""+url
        album(name,url)

elif mode==7:
        print ""+url
        yeni_album(url)

elif mode==8:
        print ""+url
        AlbumDownloaderClass(url,name,img)

elif mode==9:
        print ""+url
        SongDownloaderClass(url,name)

elif mode==10:
    print ""+url
    if __settings__.getSetting("pls_folder")=="false":
        dialog = xbmcgui.Dialog()
        path = __settings__.setSetting("pls_folder", dialog.browse(3,'Ordner Fuer Playlists aussuchen','files'))
        kb = xbmc.Keyboard('', 'Name der Playlist', False)
        kb.doModal()
        gelen = kb.getText()
        if gelen !='':
            create_playlst(gelen+'.m3u',__settings__.getSetting("pls_folder"))
            __settings__.setSetting("pls_file", __settings__.getSetting("pls_folder")+gelen+'.m3u')
    else:
        kb = xbmc.Keyboard('', 'Name der Playlist', False)
        kb.doModal()
        gelen = kb.getText()
        if gelen !='':
            create_playlst(gelen+'.m3u',__settings__.getSetting("pls_folder"))
            __settings__.setSetting("pls_file", __settings__.getSetting("pls_folder")+gelen+'.m3u')

elif mode==11:
        album2pls(url,name)

elif mode==12:
        song2pls(url,name)

elif mode==13:
        select_pls()

elif mode==14:
        del_pls()

elif mode==15:
        index_pls()

elif mode==16:
        read_m3u(url)

elif mode==17:
        sayfa_git(url,modus)

elif mode==18:
        sayfa_git_alb(url,modus)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
