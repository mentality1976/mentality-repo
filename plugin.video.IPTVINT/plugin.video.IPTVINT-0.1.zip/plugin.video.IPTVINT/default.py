import urllib,urllib2,re,xbmcplugin,xbmcgui

#TV DASH - by You 2008.

def CATEGORIES(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match3=re.compile('<a class="autoindex_a" href="(.*?)"').findall(link)
        for url in match3:
            if ".m3u" in url:
                if "Turk" in url or "trt" in url or "DTURK" in url:
                    mac=re.search("./m3u/(.*?)/", url).group(1)
                    name=url.replace("./m3u/" + mac + "/","").replace(".m3u","")
                    if mac != name:
                        addDir(name,'http://hasbahcaiptv.com'+url.replace("./","/"),1,'')
        for url in match3:
            if ".m3u" in url:
                if "Turk" not in url and "XXX" not in url and "trt" not in url and "DTURK" not in url:
                    mac=re.search("./m3u/(.*?)/", url).group(1)
                    name=url.replace("./m3u/" + mac + "/","").replace(".m3u","")
                    if str(mac) != str(name):
                        addDir(name,'http://hasbahcaiptv.com'+url.replace("./","/"),1,'')
            elif "/index.php?dir=" in url and url.replace("/index.php?dir=m3u/", ""):
                print url
                try:
                    name=re.search('/index.php\?dir=m3u/(.*?)/', url).group(1)
                    addDir(name,url,2,'')
                except:
                    pass
                
        xbmc.executebuiltin("Container.SetViewMode(400)")
        
def INDEX(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('#EXTINF:.*?,(.*?)\r\n(.*?)\r\n').findall(link)
        for i,e in match:
                addLink(i.replace('***HasBahCa','***').replace('by_HasBahCa',''),e.replace('<swfUrl>',' swfUrl=').replace('<pageUrl>',' pageUrl=').replace('<live>',' live=') .replace('<playpath>',' playpath=').replace('<playpath>',' playpath=').replace('<object encoding>','').replace('rtmp://$OPT:rtmp-raw=','').strip(),"")
        xbmc.executebuiltin("Container.SetViewMode(400)")

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

def addLink(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=str(iconimage))
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok


def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&img="+urllib.quote_plus(iconimage)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
        
              
params=get_params()
url=None
name=None
mode=None
img=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        img=urllib.unquote_plus(params["img"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)

if mode==None or url==None or len(url)<1:
        print ""
        CATEGORIES('http://hasbahcaiptv.com/index.php?dir=m3u/')
       
elif mode==1:
        print ""+url
        INDEX(url)
elif mode==2:
        print ""+url
        CATEGORIES("http://hasbahcaiptv.com"+url)



xbmcplugin.endOfDirectory(int(sys.argv[1]))
