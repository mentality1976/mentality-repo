# -*- coding: utf-8 -*-
import sys,os
import urllib,urllib2
import re,xbmcplugin,xbmcgui,xbmcaddon,xbmc
import json,mechanize
from Playlist import playlst
addon_id = 'plugin.audio.CatlaEmi'
addon = xbmcaddon.Addon(addon_id)
__settings__ = xbmcaddon.Addon(id=addon_id)
datapath = __settings__.getAddonInfo('path')
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
js = json.loads(playlst.decode('utf-8'))
def SANATCILAR():
        sanat=[]
        for san in js:
            sanatci=san['Sanatci'].encode('utf-8')
            if sanatci not in sanat:
                sanat.append(sanatci)
        sanat.sort()
        for san in sanat:
            addDir(san,san,'',1,'')
            
def ALBUMLAR(sanatci):
        for san in js:
            if sanatci == san['Sanatci'].encode('utf-8'):
                # print san['Sanatci']
                for i in san['Album']:
                    album = i['Name'].encode('utf-8')
                    image = i['Image'].encode('utf-8')
                    year = i['Year'].encode('utf-8')
                    addDir(album+' ( '+str(year)+' )',sanatci,album,2,image)
        
def PARCALAR(sanatci,album,iconimage):
        # addDir('Download Album',sanatci,album,3,'')
        for san in js:
            if sanatci==san['Sanatci'].encode('utf-8'):
                for alb in san['Album']:
                    if album==alb['Name'].encode('utf-8'):
                        tracks = alb['Tracks']
                        for track in tracks:
                            if 'picosong' in track['Link']:
                                if 'download' in track['Link']:
                                    link = GETLINK(track['Link'])
                                else:
                                    link1 = track['Link'].replace('com/','com/download/')
                                    link = GETLINK(link1)
                                infolabels = INFOLABELS_PICO(track['Link'].replace("/download",""))
                                addLink(link,iconimage,infolabels)
                            else:
                                infolabel = INFOLABELS_HEX(track['Link'],alb['Name'].encode('utf-8'),san['Sanatci'].encode('utf-8'),alb['Year'])
                                try:
                                    addLink(infolabel[1],iconimage,infolabel[0])
                                except:
                                    pass
# def download(sanatci,album):
        # for san in js:
            # if sanatci==san['Sanatci'].encode('utf-8'):
                # for alb in san['Album']:
                    # if album==alb['Name'].encode('utf-8'):
                        # tracks = alb['Tracks']
                        # for track in tracks:
                            # if 'picosong' in track['Link']:
                                # if 'download' in track['Link']:
                                    # link = GETLINK(track['Link'])
                                # else:
                                    # link1 = track['Link'].replace('com/','com/download/')
                                    # link = GETLINK(link1)
                                # infolabels = INFOLABELS_PICO(track['Link'].replace("/download",""))
                                # addLink(link,'',infolabels)
                            # else:
                                # infolabel = INFOLABELS_HEX(track['Link'],alb['Name'].encode('utf-8'),san['Sanatci'].encode('utf-8'),alb['Year'])
                                # try:
                                    # mp3file = urllib2.urlopen(str(infolabel[1]))
                                    # output = open((str(infolabel[0]['Artist'])+' - '+str(infolabel[0]['Album'])+' - '+str(infolabel[0]['Title'])+'.mp3'),'wb')
                                    # output.write(mp3file.read())
                                    
                                # except:
                                    # print 'OLMUYOR'
                                    

def GETLINK(link):
        content = get_url(link)
        audio = (re.search('<a href="(.*?)/">click here to <strong>download</strong>',content).group(1))
        return 'http://picosong.com'+audio
        
def INFOLABELS_PICO(url):
        info=[]
        content = get_url(url)
        try:
            Title = re.search('<dt>Title</dt>\n\s*<dd>(.*?)&nbsp;</dd>',content).group(1)
        except:
            Titile = ''
        try:
            Artist = re.search('<dt>Artist</dt>\n\s*<dd>(.*?)&nbsp;</dd>',content).group(1)
        except:
            Artist = ''
        try:
            Album = re.search('<dt>Album</dt>\n\s*<dd>(.*?)&nbsp;</dd>',content).group(1)
        except:
            Album = ''
        try:
            Length = re.search('<dt>Length</dt>\n\s*<dd>(.*?)&nbsp;</dd>',content).group(1)
            temp = Length.split(":")
            duration = (int(temp[0])*60)+int(temp[1])
        except:
            duration = 0
        try:
            Year = int(re.search('<dt>Year</dt>\n\s*<dd>(.*?)&nbsp;</dd>',content).group(1))
        except:
            Year = 0
        try:
            Genre = re.search('<dt>Genre</dt>\n\s*<dd>(.*?)&nbsp;</dd>',content).group(1)
        except:
            Genre = ''
        try:
            Track = int(re.search('<dt>Track</dt>\n\s*<dd>(.*?)&nbsp;</dd>',content).group(1))
        except:
            Track = 0
        return {"Title":Title,"Artist":Artist,"Album":Album,"Duration":duration,"Year":Year,"Genre":Genre,"Track":Track}     
        
def INFOLABELS_HEX(url,Album,sanatci,year):
        br = mechanize.Browser()
        br.set_handle_robots(False)   # ignore robots
        br.set_handle_refresh(False)  # can sometimes hang without this
        br.addheaders = [('User-agent', 'Chrome')]
        code = re.search('.*?com/(.*?)$',url).group(1)
        print code
        data = {
            'op' : 'download1',
            'usr_login' : '',
            'id' : code,
            'fname' : '',
            'referer' : url,
            'method_free' : 'Kostenloser Download'
            }
        content = br.open(url, urllib.urlencode( data)).read()
        Title = None
        Artist = None
        file = None
        if '.mp3' in content:
            try:
                Title = re.search('Filename:</b></td><td nowrap>.*? - (.*?)\.mp3</td></tr>',content,re.I).group(1)
            except:
                Title = ''
            try:
                Artist = re.search('Filename:</b></td><td nowrap>(.*?) - .*?\.mp3</td></tr>',content).group(1)
            except:
                Artist = sanatci
            try:
                file = re.search("so.addVariable\('file','(.*?)'\);",content).group(1)
            except:
                file = None
        elif '.wma' in content:
            try:
                Title = re.search('Filename:</b></td><td nowrap>.*? - (.*?)\.wma</td></tr>',content,re.I).group(1)
            except:
                Title = ''
            try:
                Artist = re.search('Filename:</b></td><td nowrap>(.*?) - .*?\.wma</td></tr>',content).group(1)
            except:
                Artist = sanatci
            try:
                file = re.search('<a href="(.*?\.wma)">.*?\.wma</a>',content).group(1)
            except:
                file = None
        try:
            duration = re.search("so.addVariable\('duration','(.*?)'\)",content).group(1)
        except:
            duration = 0
        dur = {"Title":Title,"Artist":Artist,"Album":Album,"Duration":duration,"Year":year,"Genre":"Turk-Musik","Track":None}
        return (dur, file)

def get_url(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        return link
        
def addLink(url,iconimage,info):
        ok=True
        infoLabels = {
            'Title': info['Title'],
            'Artist': info['Artist'],
            'Album': info['Album'],
            'Duration': info['Duration'],
            'Year': info['Year'],
            'Genre': info['Genre'],
            'Tracknumber': info['Track']
        }
        if iconimage != None:
            liz=xbmcgui.ListItem(info['Title'], iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        else:
            liz=xbmcgui.ListItem(info['Title'], iconImage="DefaultVideo.png", thumbnailImage=datapath+'\\icon.png')
        liz.setProperty('IsPlayable', 'true')
        liz.setProperty('Music', 'true')
        liz.setProperty('mimetype', 'audio/mpeg')
        liz.setInfo(type='music', infoLabels=infoLabels)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok

def addDir(name,sanatci,album,mode,iconimage):
        u=sys.argv[0]+"?album="+urllib.quote_plus(album)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&sanatci="+urllib.quote_plus(sanatci)+"&iconimage="+urllib.quote_plus(iconimage)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Music", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
params=get_params()
url=None
album=None
name=None
sanatci=None
mode=None
iconimage=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        album=urllib.unquote_plus(params["album"])
except:
        pass
try:
        sanatci=urllib.unquote_plus(params["sanatci"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass

if mode==None:
        SANATCILAR()
       
elif mode==1:
        ALBUMLAR(sanatci)
        
elif mode==2:
        PARCALAR(sanatci,album,iconimage)
        
# elif mode==3:
        # download(sanatci,album)

xbmcplugin.endOfDirectory(int(sys.argv[1]))

