import urllib,urllib2,re,xbmcplugin,xbmcgui
from BeautifulSoup import BeautifulSoup as BS

#TV DASH - by You 2008.

def CATEGORIES(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match3=re.compile('<li id="(.*?)" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item\-.*?"><a href="(.*?)">(.*?)</a>\n<ul class="sub-menu">').findall(link)
        print str(match3)
        # print link
        addDir('Search articles','','http://www.dokuhouse.de/',4,'')
        addDir('Latest articles','','http://www.dokuhouse.de/',2,'')
        for id,url,name in match3:
            addDir(name,id,url,1,'')
        xbmc.executebuiltin("Container.SetViewMode(300)")
        
def SEARCH(url):
        kb = xbmc.Keyboard('', 'Search Dokuhouse', False)
        kb.doModal()
        search = kb.getText()
        search=search.decode('utf-8').encode('iso-8859-1')
        search=urllib.quote(search)
        url_search = 'http://www.dokuhouse.de/?s='+search
        VIDEOIDX(url_search)
        
def INDEX(url,name,id):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        soup = BS(link)
        for li in soup.find("li",{"id": id},smartQuotesTo=None).find('ul',{"class": "sub-menu"},smartQuotesTo=None):
            match=re.compile('<li id="menu-item-.*?" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-.*?"><a href="(.*?)">(.*?)</a></li>').findall(str(li))
            for url,name in match:
                addDir(name,'',url,2,'')
        xbmc.executebuiltin("Container.SetViewMode(300)")

def VIDEOIDX(url1):
        req = urllib2.Request(url1)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        soup = BS(link)
        for div in soup.find('div', {"class": "main-loop-inner"}).findAll('div',{"class": "panel-wrapper"}):
            url = div.find('a')['href']
            img = div.find('img')['src']
            name = (div.find('img')['alt']).encode('utf-8')
            addDir(name,'',url,3,img)
        try:
            url=url1
            if 'page/' in url1:
                url = re.search('(.*?)page/.*?',url1).group(1)
                print url
            for seite in soup.find('div', {"class": "span12 pagination-inner-mobile"}).find('div',{"class": "sort-buttons"}):
                if 'inactive' in str(seite) and '&raquo' not in str(seite) and str(seite) !=' ':
                    addDir('Seite'+seite['data-paginated'],'',url+'page/'+seite['data-paginated'],2,'')
        except:
                pass
        xbmc.executebuiltin("Container.SetViewMode(500)")

def PLAY(name,url,iconimage):
        pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        pl.clear()
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        try:
            code = re.search('iframe width=".*?" height=".*?" src=".*?//.*?/.*?/(.*?)\?.*?" frameborder=',link, re.I).group(1)
        except:
            pass
        try:
            code = re.search('<iframe src="http://.*?/.*?/(.*?)\?$" frameborder=".*?" width=".*?" height=".*?"></noscript></iframe>',link, re.I).group(1)
        except:
            pass
        print code
        addLink(name,'plugin://plugin.video.youtube/?action=play_video&videoid=' + str(code),str(iconimage))
        # addLink(name,'plugin://plugin.video.youtube/play/?video_id=' + str(code),str(iconimage)) ##Neuer Code wenn der obere nicht funktioniert dies aktivieren
        listitem = xbmcgui.ListItem(name,thumbnailImage=str(iconimage))
        xbmc.PlayList(1).add('plugin://plugin.video.youtube/?action=play_video&videoid=' + str(code), listitem)
        # xbmc.PlayList(1).add('plugin://plugin.video.youtube/play/?video_id=' + str(code)' + str(code), listitem) ##Neuer Code wenn der obere nicht funktioniert dies aktivieren
        xbmc.Player().play(pl)

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

def addLink(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok


def addDir(name,id,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&id="+urllib.quote_plus(id)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
        
              
params=get_params()
url=None
name=None
mode=None
id=None
iconimage=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        id=urllib.unquote_plus(params["id"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["thumbnailImage"])
except:
        pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)

if mode==None or url==None or len(url)<1:
        print ""
        CATEGORIES('http://www.dokuhouse.de/dokus/')
       
elif mode==1:
        print ""+url
        INDEX(url,name,id)
        
elif mode==2:
        print ""+url
        VIDEOIDX(url)
        
elif mode==3:
        PLAY(name,url,iconimage)
        
elif mode==4:
        SEARCH(url)



xbmcplugin.endOfDirectory(int(sys.argv[1]))
