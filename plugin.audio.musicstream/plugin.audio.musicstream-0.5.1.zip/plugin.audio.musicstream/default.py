#!/usr/bin/python
# -*- coding: utf-8 -*-
# Coded by Mentality

import urllib,urllib2,re,os,sys,xbmcplugin,xbmcgui,xbmc,xbmcaddon,errno
import json as api
from BeautifulSoup import BeautifulSoup as BS
import HTMLParser
html_parser = HTMLParser.HTMLParser()
addon_id = 'plugin.audio.musicstream'
addon = xbmcaddon.Addon(addon_id)
__settings__ = xbmcaddon.Addon(addon_id)
al_folder = __settings__.getSetting("al_folder")
so_folder = __settings__.getSetting("so_folder")
datapath = __settings__.getAddonInfo('path')
channels1 = xbmc.translatePath(os.path.join(datapath, 'resources', 'images'))
sys.path.append(channels1)
channels = xbmc.translatePath(os.path.join(datapath, 'lib'))
sys.path.append(channels)
def CATEGORIES(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        soup = BS(link)
        addDir('[COLOR green][B]>>>>>>>>>>>>>>>>>[/B][/COLOR][COLOR gold][B] SEARCH FOR MUSIC [/B][/COLOR][COLOR green][B] <<<<<<<<<<<<<<<<<[/B][/COLOR]',url,2,'0')
        addDir('[COLOR yellow]ALBUMS[/COLOR]','http://musicstream.cc/',4,'0')
        
        for div in soup.findAll('table',  {"class": "boxhotlist"},smartQuotesTo=None):
            url_kat=div.findAll('a')
            for i in url_kat:
                match=re.match('<a href="(.*?)">(.*?)</a>',str(i))
                addDir('[COLOR aqua]'+match.group(2)+'[/COLOR]','http://musicstream.cc'+(match.group(1)).replace("&amp;","&"),1,'')
        xbmc.executebuiltin("Container.SetViewMode(400)")
        
def INDEX(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('<a href="(.*?)" class="ainfo">(.*?)</a>').findall(link)
        for url1,name in match:
            addDir((html_parser.unescape(name)).encode('utf-8'),'http://musicstream.cc'+html_parser.unescape(str(url1)),3,'')
        navi=re.compile('<a title="(.*?)" href="(.*?)" class="(.*?)">.*?</a>').findall(link)
        for title,strm,clas in navi:
            if clas=="hot":
                addDir(html_parser.unescape(title.decode('utf-8')),'http://musicstream.cc'+html_parser.unescape(strm),1,'')
        xbmc.executebuiltin("Container.SetViewMode(400)")
        
def INDEX_ALBUM(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('a href="(.*?)" class="dir"><img alt="(.*?)" sr').findall(link)
        for url1,name in match:
            addDir(html_parser.unescape(name),'http://musicstream.cc'+html_parser.unescape(str(url1)),3,'')
        xbmc.executebuiltin("Container.SetViewMode(400)")
        
def SEARCH(url,mode):
        kb = xbmc.Keyboard('', 'Search on Musicstream.cc', False)
        kb.doModal()
        search = kb.getText()
        search=urllib.quote(search)
        url_search = 'http://musicstream.cc/index.php?action=search&searchtext='+search+'&searchwh='+mode
        
def DATEIEN(album_name,url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match_name=re.search('class="dirheadline" href=".*?">/(.*?)/</a>',link).group(1)
        pattern='''name="playwin" value="Album" onclick="flashwin\('playwin', '(.*?)', 550, 500\);'''
        match=re.search(pattern,link).group(1)
        req = urllib2.Request("http://musicstream.cc"+html_parser.unescape(match))
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link1=response.read()
        response.close()
        mix=re.compile("image: \"(.*?)\", file: '(.*?)', title: '(.*?)'").findall(link1)
        for img,id,name in mix:
            addLink(html_parser.unescape(name),html_parser.unescape(id),"http://musicstream.cc"+html_parser.unescape(img),html_parser.unescape(match_name),'',None,"","http://musicstream.cc"+html_parser.unescape(match))

def mkdir_p(path):
    try:
        os.makedirs(path)
    except OSError as exc: # Python >2.5
        if exc.errno == errno.EEXIST and os.path.isdir(path):
            pass
        else: raise

def AlbumDownloaderClass(url,path):
    mkdir_p(al_folder+path)
    response=urllib2.urlopen(url)
    link=response.read()
    match=re.compile("image: \".*?\", file: '(.*?)', title: '(.*?)'").findall(link)
    print str(match)
    for url1,name in match:
        dp = xbmcgui.DialogProgressBG()
        dp.create(path,"Downloading "+name)
        urllib.urlretrieve(url1,al_folder+path+'/'+name+'.mp3',lambda nb, bs, fs, url=url: _pbhook(nb,bs,fs,url,dp))

def SongDownloaderClass(url,name):
    dp = xbmcgui.DialogProgressBG()
    dp.create("Song Download","Downloading "+name)
    urllib.urlretrieve(url,so_folder+name+'.mp3',lambda nb, bs, fs, url=url: _pbhook(nb,bs,fs,url,dp))

def _pbhook(numblocks, blocksize, filesize, url=None,dp=None):
    try:
        percent = min((numblocks*blocksize*100)/filesize, 100)
        dp.update(percent)
    except:
        percent = 100
        dp.update(percent)
    if percent==100:
        print "DOWNLOAD FINISHED" 
        dp.close()

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

def addLink(name,url,iconimage,album_name,artist,year,duration,album_url):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=str(iconimage))
        liz.setInfo( type="Music", infoLabels={ "Title": name, "Album": album_name, "Artist": artist, "Year": year, "Duration": duration } )
        contextMenuItems = []
        contextMenuItems.append(('Album downloaden', 'XBMC.RunPlugin(%s?mode=5&name=%s&url=%s)'% (sys.argv[0], urllib.quote_plus(album_name),urllib.quote_plus(album_url))))
        contextMenuItems.append(('Song downloaden', 'XBMC.RunPlugin(%s?mode=6&name=%s&url=%s)'% (sys.argv[0], urllib.quote_plus(name),urllib.quote_plus(url))))
        liz.addContextMenuItems(contextMenuItems, replaceItems=False)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok


def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&img="+urllib.quote_plus(iconimage)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
        
              
params=get_params()
url=None
name=None
mode=None
img=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        img=urllib.unquote_plus(params["img"])
except:
        pass


print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "Image: "+str(img)

if mode==None or url==None or len(url)<1:
        print ""
        CATEGORIES('http://musicstream.cc/index.php')
       
elif mode==1:
        print ""+url
        INDEX(url)
        
elif mode==2:
        print ""+url
        SEARCH(url,img)
        
elif mode==3:
        print ""+url
        DATEIEN(name,url)
        
elif mode==4:
        print ""+url
        INDEX_ALBUM(url)
        
elif mode==5:
        print ""+url
        AlbumDownloaderClass(url,name)
        
elif mode==6:
        print ""+url
        SongDownloaderClass(url,name)



xbmcplugin.endOfDirectory(int(sys.argv[1]))
