#!/usr/bin/python
# -*- coding: utf-8 -*-
# Coded by Mentality
import re,urllib,urllib2,os,errno,xbmc,xbmcgui,xbmcaddon
addon_id = 'plugin.audio.musicstream'
addon = xbmcaddon.Addon(addon_id)
__settings__ = xbmcaddon.Addon(addon_id)
al_folder = __settings__.getSetting("al_folder")
print al_folder
datapath = __settings__.getAddonInfo('path')
channels1 = xbmc.translatePath(os.path.join(datapath, 'resources', 'images'))
sys.path.append(channels1)
channels = xbmc.translatePath(os.path.join(datapath, 'lib'))
sys.path.append(channels)

liste = sys.argv[1:][0].split(';')
url=liste[1]
print url
path=liste[0]
def mkdir_p(path):
    try:
        os.makedirs(path)
    except OSError as exc: # Python >2.5
        if exc.errno == errno.EEXIST and os.path.isdir(path):
            pass
        else: raise
mkdir_p(al_folder+path)
print "gaeht"
def DownloaderClass(url,dest,name,path):
    dp = xbmcgui.DialogProgressBG()
    dp.create(path,"Downloading "+name)
    urllib.urlretrieve(url,dest,lambda nb, bs, fs, url=url: _pbhook(nb,bs,fs,url,dp))
 
def _pbhook(numblocks, blocksize, filesize, url=None,dp=None):
    try:
        percent = min((numblocks*blocksize*100)/filesize, 100)
        dp.update(percent)
    except:
        percent = 100
        dp.update(percent)
    if percent==100:
        print "DOWNLOAD FINISHED" 
        dp.close()
 
response=urllib2.urlopen(url)
link=response.read()
match=re.compile("image: \".*?\", file: '(.*?)', title: '(.*?)'").findall(link)
print str(match)
for url1,name in match:
    DownloaderClass(url1,al_folder+path+'/'+name+'.mp3',name,path)
