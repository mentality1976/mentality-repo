#!/usr/bin/python
# -*- coding: utf-8 -*-
# Coded by Mentality
import re,urllib,urllib2,os,errno,xbmc,xbmcgui,xbmcaddon
addon_id = 'plugin.audio.musicstream'
addon = xbmcaddon.Addon(addon_id)
__settings__ = xbmcaddon.Addon(addon_id)
so_folder = __settings__.getSetting("so_folder")
datapath = __settings__.getAddonInfo('path')
channels1 = xbmc.translatePath(os.path.join(datapath, 'resources', 'images'))
sys.path.append(channels1)
channels = xbmc.translatePath(os.path.join(datapath, 'lib'))
sys.path.append(channels)

liste = sys.argv[1:][0].split(';')
url=liste[1]
print url
name=liste[0]

print "gaeht"
def DownloaderClass(url,dest,name):
    dp = xbmcgui.DialogProgressBG()
    dp.create("Song Download","Downloading "+name)
    urllib.urlretrieve(url,dest,lambda nb, bs, fs, url=url: _pbhook(nb,bs,fs,url,dp))
 
def _pbhook(numblocks, blocksize, filesize, url=None,dp=None):
    try:
        percent = min((numblocks*blocksize*100)/filesize, 100)
        dp.update(percent)
    except:
        percent = 100
        dp.update(percent)
    if percent==100:
        print "DOWNLOAD FINISHED" 
        dp.close()

DownloaderClass(url,so_folder+name+'.mp3',name)
