#!/usr/bin/python
# -*- coding: utf-8 -*-
# Coded by Mentality

import urllib,urllib2,re,xbmcplugin,xbmcgui,xbmc
from BeautifulSoup import BeautifulSoup as BS

def CATEGORIES(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        soup = BS(link)
        div = soup.findAll('div',  {"class": "navi"},smartQuotesTo=None)
        # print div
        match=re.compile('<a href="(.*?)" class="hot">(.*?)</a>').findall(link)
        addDir('[COLOR green][B]>>>>>>>>>>>>>>>>>>>[/B][/COLOR][COLOR gold][B] SEARCH FOR MUSIC [/B][/COLOR][COLOR green][B] <<<<<<<<<<<<<<<<<<<[/B][/COLOR]',url,2,'')
        for url,name in match:
            addDir('[COLOR aqua]'+name+'[/COLOR]','http://musicstream.cc'+url.replace("&amp;","&"),1,'')
        xbmc.executebuiltin("Container.SetViewMode(400)")
        
def INDEX(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('<a href="(.*?)" class="ainfo">(.*?)</a>').findall(link)
        for url1,name in match:
            addDir(name.replace('&amp;',"&"),'http://musicstream.cc'+str(url1).replace('&amp;',"&"),3,'')
        soup=BS(link)
        for div in soup.findAll('div', {"class": "navigation"},smartQuotesTo=None):
            lank=div.findAll('a')
            for i in lank:
                if i['class']=="hot":
                    addDir(i['title'].replace('&amp;',"&"),'http://musicstream.cc'+i['href'].replace('&amp;',"&"),1,'')
        xbmc.executebuiltin("Container.SetViewMode(400)")

def SEARCH(url):
        kb = xbmc.Keyboard('', 'Search on Musicstream.cc', False)
        kb.doModal()
        search = kb.getText()
        search=urllib.quote(search)
        url_search = 'http://musicstream.cc/index.php?action=search&searchfor='+search
        INDEX(url_search)
        
def DATEIEN(album_name,url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        soup = BS(link)
        id=None
        for div in soup.findAll('div',  {"id": "mainwrapper"},smartQuotesTo=None):
            id=div.find('td')
        response.close()
        match=re.compile("a href=\"\" onclick=\"javascript: flashwin\('playwin', '(.*?)', 550, 500\); return false;\" title=\"(.*?)\s(\d\d\d\d)\"><span class=\".*?\">.*?</span></a> <span class=\"finfo\">\(.*? kbit (.*?) mins\).*?<").findall(str(id))
        if match==[]:
            match=re.compile("a href=\"\" onclick=\"javascript: flashwin\('playwin', '(.*?)', 550, 500\); return false;\"><span class=\"file\">.*?</span></a> <span class=\"finfo\">\(.*? kbit (.*?) mins\) .*? MB<").findall(str(id))
            for id,min in match:
                try:
                    temp = min.split(":")
                    duration = (int(temp[0])*60)+int(temp[1])
                    id='http://musicstream.cc'+str(id).replace("&amp;","&")
                    req = urllib2.Request(id)
                    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
                    response = urllib2.urlopen(req)
                    link1=response.read()
                    response.close()
                    go=re.search("SWFObject\('mediaplayer-3-16/mediaplayer.swf\?file=\%2Findex.php\%3Ftemplist\%3D2\%26c\%3D\%26file\%3D(.*?).xml','mpl',480,540,'8'\)",str(link1)).group(1)
                    mpxml='http://musicstream.cc/index.php?templist=2&c=&file='+go+'.xml'
                    req = urllib2.Request(mpxml)
                    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
                    response = urllib2.urlopen(req)
                    link2=response.read()
                    response.close()
                    location=re.search('<location>(.*?)</location>',link2).group(1)
                    title=re.search('<title>(.*?)</title>',link2).group(1)
                    image=re.search('<image>(.*?)</image>',link2).group(1)
                    addLink(str(title),str(location),('http://musicstream.cc'+str(image).replace("&amp;","&")),album_name,'',None,duration)
                except:
                        pass
        else:
            for id,artist,year,min in match:
                try:
                    temp = min.split(":")
                    duration = (int(temp[0])*60)+int(temp[1])
                    id='http://musicstream.cc'+str(id).replace("&amp;","&")
                    req = urllib2.Request(id)
                    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
                    response = urllib2.urlopen(req)
                    link1=response.read()
                    response.close()
                    go=re.search("SWFObject\('mediaplayer-3-16/mediaplayer.swf\?file=\%2Findex.php\%3Ftemplist\%3D2\%26c\%3D\%26file\%3D(.*?).xml','mpl',480,540,'8'\)",str(link1)).group(1)
                    mpxml='http://musicstream.cc/index.php?templist=2&c=&file='+go+'.xml'
                    req = urllib2.Request(mpxml)
                    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
                    response = urllib2.urlopen(req)
                    link2=response.read()
                    response.close()
                    location=re.search('<location>(.*?)</location>',link2).group(1)
                    title=re.search('<title>(.*?)</title>',link2).group(1)
                    image=re.search('<image>(.*?)</image>',link2).group(1)
                    addLink(str(title),str(location),('http://musicstream.cc'+str(image).replace("&amp;","&")),album_name,artist,int(year),duration)
                except:
                        pass

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

def addLink(name,url,iconimage,album_name,artist,year,duration):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=str(iconimage))
        liz.setInfo( type="Music", infoLabels={ "Title": name, "Album": album_name, "Artist": artist, "Year": year, "Duration": duration } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok


def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
        
              
params=get_params()
url=None
name=None
mode=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass


print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)

if mode==None or url==None or len(url)<1:
        print ""
        CATEGORIES('http://musicstream.cc/index.php')
       
elif mode==1:
        print ""+url
        INDEX(url)
        
elif mode==2:
        print ""+url
        SEARCH(url)
        
elif mode==3:
        print ""+url
        DATEIEN(name,url)



xbmcplugin.endOfDirectory(int(sys.argv[1]))
