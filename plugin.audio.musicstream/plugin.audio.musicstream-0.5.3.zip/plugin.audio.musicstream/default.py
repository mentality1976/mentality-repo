#!/usr/bin/python
# -*- coding: utf-8 -*-
# Coded by Mentality

import urllib,urllib2,re,os,sys,xbmcplugin,xbmcgui,xbmc,xbmcaddon,errno,time
import json as api
from BeautifulSoup import BeautifulSoup as BS
import HTMLParser
html_parser = HTMLParser.HTMLParser()
addon_id = 'plugin.audio.musicstream'
addon = xbmcaddon.Addon(addon_id)
__settings__ = xbmcaddon.Addon(addon_id)
al_folder = __settings__.getSetting("al_folder")
so_folder = __settings__.getSetting("so_folder")
pls_folder = __settings__.getSetting("pls_folder")
pls_file = __settings__.getSetting("pls_file")
datapath = __settings__.getAddonInfo('path')
channels1 = xbmc.translatePath(os.path.join(datapath, 'resources', 'images'))
sys.path.append(channels1)
channels = xbmc.translatePath(os.path.join(datapath, 'lib'))
sys.path.append(channels)
def CATEGORIES(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        soup = BS(link)
        addDir('[COLOR green][B]>>>>>>>>>>>>>>>>>[/B][/COLOR][COLOR gold][B] SEARCH FOR MUSIC [/B][/COLOR][COLOR green][B] <<<<<<<<<<<<<<<<<[/B][/COLOR]',url,2,'0')
        addDir('[COLOR yellow]ALBUMS[/COLOR]','http://musicstream.cc/',4,'0')
        addDir('[COLOR blue]MYPLAYLISTS[/COLOR]','http://musicstream.cc/',12,'0')

        for div in soup.findAll('table',  {"class": "boxhotlist"},smartQuotesTo=None):
            url_kat=div.findAll('a')
            for i in url_kat:
                match=re.match('<a href="(.*?)">(.*?)</a>',str(i))
                addDir('[COLOR aqua]'+match.group(2)+'[/COLOR]','http://musicstream.cc'+(match.group(1)).replace("&amp;","&"),1,'')
        xbmc.executebuiltin("Container.SetViewMode(400)")

def INDEX(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('<a href="(.*?)" class="ainfo">(.*?)</a>').findall(link)
        for url1,name in match:
            addDir((html_parser.unescape(name)).encode('utf-8'),'http://musicstream.cc'+html_parser.unescape(str(url1)),3,'')
        navi=re.compile('<a title="(.*?)" href="(.*?)" class="(.*?)">.*?</a>').findall(link)
        for title,strm,clas in navi:
            if clas=="hot":
                addDir(html_parser.unescape(title.decode('utf-8')),'http://musicstream.cc'+html_parser.unescape(strm),1,'')
        xbmc.executebuiltin("Container.SetViewMode(400)")

def INDEX_ALBUM(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('a href="(.*?)" class="dir"><img alt="(.*?)" sr').findall(link)
        for url1,name in match:
            addDir(html_parser.unescape(name),'http://musicstream.cc'+html_parser.unescape(str(url1)),3,'')
        xbmc.executebuiltin("Container.SetViewMode(400)")

def SEARCH(url,mode):
        kb = xbmc.Keyboard('', 'Search on Musicstream.cc', False)
        kb.doModal()
        search = kb.getText()
        search=urllib.quote(search)
        url_search = 'http://musicstream.cc/index.php?action=search&searchtext='+search+'&searchwh='+mode

def DATEIEN(album_name,url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match_name=re.search('class="dirheadline" href=".*?">/(.*?)/</a>',link).group(1)
        pattern='''name="playwin" value="Album" onclick="flashwin\('playwin', '(.*?)', 550, 500\);'''
        match=re.search(pattern,link).group(1)
        req = urllib2.Request("http://musicstream.cc"+html_parser.unescape(match))
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link1=response.read()
        response.close()
        mix=re.compile("image: \"(.*?)\", file: '(.*?)', title: '(.*?)'").findall(link1)
        for img,id,name in mix:
            addLink(html_parser.unescape(name),html_parser.unescape(id),"http://musicstream.cc"+html_parser.unescape(img),html_parser.unescape(match_name),'',None,"","http://musicstream.cc"+html_parser.unescape(match))

def mkdir_p(path):
    try:
        os.makedirs(path)
    except OSError as exc: # Python >2.5
        if exc.errno == errno.EEXIST and os.path.isdir(path):
            pass
        else: raise

def AlbumDownloaderClass(url,path):
    if __settings__.getSetting("al_folder")=="false":
        select_al_folder()
    mkdir_p(__settings__.getSetting("al_folder")+path)
    response=urllib2.urlopen(url)
    link=response.read()
    match=re.compile("image: \".*?\", file: '(.*?)', title: '(.*?)'").findall(link)
    print str(match)
    for url1,name in match:
        dp = xbmcgui.DialogProgressBG()
        dp.create(path,"Downloading "+name)
        urllib.urlretrieve(url1,__settings__.getSetting("al_folder")+path+'/'+name+'.mp3',lambda nb, bs, fs, url=url: _pbhook(nb,bs,fs,url,dp))

def SongDownloaderClass(url,name):
    if __settings__.getSetting("so_folder")=="false":
        select_so_folder()
    dp = xbmcgui.DialogProgressBG()
    dp.create("Song Download","Downloading "+name)
    urllib.urlretrieve(url,__settings__.getSetting("so_folder")+name+'.mp3',lambda nb, bs, fs, url=url: _pbhook(nb,bs,fs,url,dp))

def _pbhook(numblocks, blocksize, filesize, url=None,dp=None):
    try:
        percent = min((numblocks*blocksize*100)/filesize, 100)
        dp.update(percent)
    except:
        percent = 100
        dp.update(percent)
    if percent==100:
        print "DOWNLOAD FINISHED"
        dp.close()

def create_playlst(name,path):
    output = open(path+name,'w')
    output.write(('#EXTM3U\r\n'))
    output.close()

def select_folder():
    dialog = xbmcgui.Dialog()
    __settings__.setSetting("pls_folder", dialog.browse(3,'Ordner Fuer Playlists aussuchen','files'))

def select_al_folder():
    dialog = xbmcgui.Dialog()
    __settings__.setSetting("al_folder", dialog.browse(3,'Ordner Fuer Playlists aussuchen','files'))

def select_so_folder():
    dialog = xbmcgui.Dialog()
    __settings__.setSetting("so_folder", dialog.browse(3,'Ordner Fuer Playlists aussuchen','files'))

def album2pls(url,name):
    if __settings__.getSetting("pls_folder")=="false":
        select_folder()
    liste = []
    response=urllib2.urlopen(url)
    link=response.read()
    match=re.compile("image: \"(.*?)\", file: '(.*?)', title: '(.*?)'").findall(link)
    path = __settings__.getSetting("pls_folder")
    output = open(path+name+'.m3u','w')
    output.write(('#EXTM3U\r\n'))
    for img,url1,name in match:
        #~ liste.append(('EXTINF:-1 tvg-logo="'+'http://musicstream.cc'+img+'",name\r\n'+url1)
        output.write(('#EXTINF:-1,'+name+'\r\n'+url1+'\r\n'))
    output.write(('#EXTINF:-1,Cover\r\n"cover": "http://musicstream.cc'+match[0][0]+'"'))
    output.close()

def song2pls(url,name):
    if __settings__.getSetting("pls_file")=="false":
        if __settings__.getSetting("pls_folder")=="false":
            dialog = xbmcgui.Dialog()
            __settings__.setSetting("pls_folder", dialog.browse(3,'Ordner Fuer Playlists aussuchen','files'))
            path = __settings__.getSetting("pls_folder")
        else:
            path = __settings__.getSetting("pls_folder")
        if ".m3u" not in str(os.listdir(__settings__.getSetting("pls_folder"))):
            kb = xbmc.Keyboard('', 'Name der neuen Playlist', False)
            kb.doModal()
            plsname = kb.getText()
            if plsname !='':
                create_playlst(plsname+'.m3u',path)
                time.sleep(2)
                __settings__.setSetting("pls_file", path+plsname+'.m3u')
                pls_file1 = __settings__.getSetting("pls_file")
        else:
            select_pls()
            pls_file1 = __settings__.getSetting("pls_file")
        output = open(pls_file1,'a')
        output.write(('#EXTM3U\r\n'))
        output.close()
        output = open(pls_file1,'a')
        output.write('#EXTINF:-1,'+name+'\r\n'+url+'\r\n')
        output.close()

    else:
        if os.path.exists(__settings__.getSetting("pls_file")):
            output = open(__settings__.getSetting("pls_file"),'a')
            output.write('#EXTINF:-1,'+name+'\r\n'+url+'\r\n')
            output.close()
        else:
            kb = xbmc.Keyboard('', 'Name der neuen Playlist', False)
            kb.doModal()
            plsname = kb.getText()
            if plsname !='':
                create_playlst(plsname+'.m3u',__settings__.getSetting("pls_folder"))
                time.sleep(2)
                __settings__.setSetting("pls_file", __settings__.getSetting("pls_folder")+plsname+'.m3u')
                pls_file1 = __settings__.getSetting("pls_file")
                output = open(pls_file1,'a')
                output.write('#EXTINF:-1,'+name+'\r\n'+url+'\r\n')
                output.close()

def select_pls():
    dialog = xbmcgui.Dialog()
    if __settings__.getSetting("pls_folder")=="false":
        select_folder()
    plslists = os.listdir(__settings__.getSetting("pls_folder"))
    liste = []
    for i in plslists:
        try:
            match=re.search('(.*?)\.m3u',i).group(1)
            liste.append(match)
        except:
            pass
    gelen = dialog.select('Eine Playlist aussuchen',liste)
    __settings__.setSetting("pls_file", __settings__.getSetting("pls_folder")+liste[gelen]+'.m3u')

def del_pls():
    dialog = xbmcgui.Dialog()
    if __settings__.getSetting("pls_folder")=='false':
        select_folder()
    plslists = os.listdir(__settings__.getSetting("pls_folder"))
    liste = []
    for i in plslists:
        try:
            match=re.search('(.*?)\.m3u',i).group(1)
            liste.append(match)
        except:
            pass
    gelen = dialog.select('Eine Playlist aussuchen',liste)
    os.remove(__settings__.getSetting("pls_folder")+liste[gelen]+'.m3u')

def index_mylists():
    for i in os.listdir(__settings__.getSetting("pls_folder")):
        if 'm3u' in i:
            print i
            addDir(i.replace(".m3u",""), __settings__.getSetting("pls_folder")+i,13,'')


def read_m3u(url):
    output = open(url,'r')
    m3u = output.readlines()
    output.close()
    playlist = []
    name = None
    url1 = None
    img = ''
    for i in m3u:
        if '#EXTM3U' in i or 'Cover' in i:
            pass
        elif 'cover' in i:
            img = re.search('"cover": "(.*?)"',i).group(1)
        elif '#EXTINF' in i:
            name = re.search('#EXTINF:-1,(.*?)\r\n',i).group(1)
            print name
        else:
            url1 = i.replace("\r\n","")
            print url1
        if name!=None and url1!=None:
            playlist.append((name,url1))
            name = None
            url1 = None
        else:
            pass
    for name,link in playlist:
        addLink(name,link,html_parser.unescape(img),'','','','','')

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]

        return param

def addLink(name,url,iconimage,album_name,artist,year,duration,album_url):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=str(iconimage))
        liz.setInfo( type="Music", infoLabels={ "Title": name, "Album": album_name, "Artist": artist, "Year": year, "Duration": duration } )
        contextMenuItems = []
        contextMenuItems.append(('Album downloaden', 'XBMC.RunPlugin(%s?mode=5&name=%s&url=%s)'% (sys.argv[0], urllib.quote_plus(album_name),urllib.quote_plus(album_url))))
        contextMenuItems.append(('Song downloaden', 'XBMC.RunPlugin(%s?mode=6&name=%s&url=%s)'% (sys.argv[0], urllib.quote_plus(name),urllib.quote_plus(url))))
        if album_name:
            contextMenuItems.append(('add Album to MyLists', 'XBMC.RunPlugin(%s?mode=8&name=%s&url=%s)'% (sys.argv[0], urllib.quote_plus(album_name),urllib.quote_plus(album_url))))
        contextMenuItems.append(('create New Playlist', 'XBMC.RunPlugin(%s?mode=7&name=%s&url=%s)'% (sys.argv[0], urllib.quote_plus(album_name),urllib.quote_plus(album_url))))
        contextMenuItems.append(('add Song to Playlist', 'XBMC.RunPlugin(%s?mode=9&name=%s&url=%s)'% (sys.argv[0], urllib.quote_plus(name),urllib.quote_plus(url))))
        contextMenuItems.append(('Select Playlist', 'XBMC.RunPlugin(%s?mode=10&name=%s&url=%s)'% (sys.argv[0], urllib.quote_plus(name),urllib.quote_plus(url))))
        contextMenuItems.append(('Delete Playlist', 'XBMC.RunPlugin(%s?mode=11&name=%s&url=%s)'% (sys.argv[0], urllib.quote_plus(name),urllib.quote_plus(url))))

        liz.addContextMenuItems(contextMenuItems, replaceItems=True)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok


def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&img="+urllib.quote_plus(iconimage)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok


params=get_params()
url=None
name=None
mode=None
img=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        img=urllib.unquote_plus(params["img"])
except:
        pass


print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "Image: "+str(img)

if mode==None or url==None or len(url)<1:
        print ""
        CATEGORIES('http://musicstream.cc/index.php')

elif mode==1:
        print ""+url
        INDEX(url)

elif mode==2:
        print ""+url
        SEARCH(url,img)

elif mode==3:
        print ""+url
        DATEIEN(name,url)

elif mode==4:
        print ""+url
        INDEX_ALBUM(url)

elif mode==5:
        print ""+url
        AlbumDownloaderClass(url,name)

elif mode==6:
        print ""+url
        SongDownloaderClass(url,name)

elif mode==7:
    print ""+url
    if __settings__.getSetting("pls_folder")=="false":
        dialog = xbmcgui.Dialog()
        path = __settings__.setSetting("pls_folder", dialog.browse(3,'Ordner Fuer Playlists aussuchen','files'))
        kb = xbmc.Keyboard('', 'Name der Playlist', False)
        kb.doModal()
        gelen = kb.getText()
        if gelen !='':
            create_playlst(gelen+'.m3u',__settings__.getSetting("pls_folder"))
            __settings__.setSetting("pls_file", __settings__.getSetting("pls_folder")+gelen+'.m3u')
    else:
        kb = xbmc.Keyboard('', 'Name der Playlist', False)
        kb.doModal()
        gelen = kb.getText()
        if gelen !='':
            create_playlst(gelen+'.m3u',__settings__.getSetting("pls_folder"))
            __settings__.setSetting("pls_file", __settings__.getSetting("pls_folder")+gelen+'.m3u')

elif mode==8:
        album2pls(url,name)

elif mode==9:
        song2pls(url,name)

elif mode==10:
        select_pls()

elif mode==11:
        del_pls()

elif mode==12:
        index_mylists()

elif mode==13:
        read_m3u(url)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
