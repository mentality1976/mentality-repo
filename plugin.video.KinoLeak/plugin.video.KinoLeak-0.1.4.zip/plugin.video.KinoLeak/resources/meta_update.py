from metahandler import metahandlers
metaget = metahandlers.MetaData(preparezip=True)
print
metaget.update_meta(status,name,imdb_id,tmdb_id)
